CREATE TABLE "branding_settings" (
	"id" serial PRIMARY KEY NOT NULL,
	"logo_url" text,
	"company_name" text NOT NULL,
	"primary_color" text DEFAULT '#1976D2' NOT NULL,
	"secondary_color" text DEFAULT '#FF9800' NOT NULL,
	"font_family" text DEFAULT 'Roboto' NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "company_documents" (
	"id" serial PRIMARY KEY NOT NULL,
	"title" text NOT NULL,
	"file_name" text NOT NULL,
	"file_size" integer NOT NULL,
	"file_type" text NOT NULL,
	"category" text NOT NULL,
	"content" text,
	"uploaded_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "rfp_documents" (
	"id" serial PRIMARY KEY NOT NULL,
	"title" text NOT NULL,
	"client_name" text NOT NULL,
	"file_name" text NOT NULL,
	"file_size" integer NOT NULL,
	"file_type" text NOT NULL,
	"content" text,
	"status" text DEFAULT 'uploaded' NOT NULL,
	"uploaded_at" timestamp DEFAULT now() NOT NULL,
	"processed_at" timestamp
);
--> statement-breakpoint
CREATE TABLE "rfp_responses" (
	"id" serial PRIMARY KEY NOT NULL,
	"rfp_document_id" integer NOT NULL,
	"title" text NOT NULL,
	"content" text,
	"status" text DEFAULT 'draft' NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "templates" (
	"id" serial PRIMARY KEY NOT NULL,
	"name" text NOT NULL,
	"description" text,
	"content" text NOT NULL,
	"category" text NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL
);
