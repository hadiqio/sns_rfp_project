import { 
  RfpDocument, 
  InsertRfpDocument,
  CompanyDocument,
  InsertCompanyDocument,
  RfpResponse,
  InsertRfpResponse,
  Template,
  InsertTemplate,
  BrandingSettings,
  InsertBrandingSettings,
  rfpDocuments,
  companyDocuments,
  rfpResponses,
  templates,
  brandingSettings,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc } from "drizzle-orm";

export interface IStorage {
  // RFP Documents
  getRfpDocument(id: number): Promise<RfpDocument | undefined>;
  getAllRfpDocuments(): Promise<RfpDocument[]>;
  createRfpDocument(doc: InsertRfpDocument): Promise<RfpDocument>;
  updateRfpDocument(id: number, updates: Partial<RfpDocument>): Promise<RfpDocument | undefined>;
  deleteRfpDocument(id: number): Promise<boolean>;

  // Company Documents
  getCompanyDocument(id: number): Promise<CompanyDocument | undefined>;
  getAllCompanyDocuments(): Promise<CompanyDocument[]>;
  getCompanyDocumentsByCategory(category: string): Promise<CompanyDocument[]>;
  createCompanyDocument(doc: InsertCompanyDocument): Promise<CompanyDocument>;
  deleteCompanyDocument(id: number): Promise<boolean>;

  // RFP Responses
  getRfpResponse(id: number): Promise<RfpResponse | undefined>;
  getAllRfpResponses(): Promise<RfpResponse[]>;
  getRfpResponsesByRfpId(rfpDocumentId: number): Promise<RfpResponse[]>;
  createRfpResponse(response: InsertRfpResponse): Promise<RfpResponse>;
  updateRfpResponse(id: number, updates: Partial<RfpResponse>): Promise<RfpResponse | undefined>;
  deleteRfpResponse(id: number): Promise<boolean>;

  // Templates
  getTemplate(id: number): Promise<Template | undefined>;
  getAllTemplates(): Promise<Template[]>;
  getTemplatesByCategory(category: string): Promise<Template[]>;
  createTemplate(template: InsertTemplate): Promise<Template>;
  updateTemplate(id: number, updates: Partial<Template>): Promise<Template | undefined>;
  deleteTemplate(id: number): Promise<boolean>;

  // Branding Settings
  getBrandingSettings(): Promise<BrandingSettings | undefined>;
  updateBrandingSettings(settings: InsertBrandingSettings): Promise<BrandingSettings>;
}

export class MemStorage implements IStorage {
  private rfpDocuments: Map<number, RfpDocument> = new Map();
  private companyDocuments: Map<number, CompanyDocument> = new Map();
  private rfpResponses: Map<number, RfpResponse> = new Map();
  private templates: Map<number, Template> = new Map();
  private brandingSettings: BrandingSettings | undefined;
  private currentId = 1;

  constructor() {
    // Initialize with default branding settings
    this.brandingSettings = {
      id: 1,
      logoUrl: null,
      companyName: "Smart National Solutions",
      primaryColor: "#00D4ED",
      secondaryColor: "#00BCD4",
      fontFamily: "Roboto",
      updatedAt: new Date(),
    };

    // Add some sample templates
    this.createTemplate({
      name: "Standard RFP Response",
      description: "Standard template for RFP responses",
      content: "This is a standard RFP response template.",
      category: "general",
    });
  }

  // RFP Documents
  async getRfpDocument(id: number): Promise<RfpDocument | undefined> {
    return this.rfpDocuments.get(id);
  }

  async getAllRfpDocuments(): Promise<RfpDocument[]> {
    return Array.from(this.rfpDocuments.values()).sort((a, b) => 
      new Date(b.uploadedAt).getTime() - new Date(a.uploadedAt).getTime()
    );
  }

  async createRfpDocument(doc: InsertRfpDocument): Promise<RfpDocument> {
    const id = this.currentId++;
    const rfpDocument: RfpDocument = {
      ...doc,
      id,
      uploadedAt: new Date(),
      processedAt: null,
    };
    this.rfpDocuments.set(id, rfpDocument);
    return rfpDocument;
  }

  async updateRfpDocument(id: number, updates: Partial<RfpDocument>): Promise<RfpDocument | undefined> {
    const existing = this.rfpDocuments.get(id);
    if (!existing) return undefined;
    
    const updated = { ...existing, ...updates };
    this.rfpDocuments.set(id, updated);
    return updated;
  }

  async deleteRfpDocument(id: number): Promise<boolean> {
    return this.rfpDocuments.delete(id);
  }

  // Company Documents
  async getCompanyDocument(id: number): Promise<CompanyDocument | undefined> {
    return this.companyDocuments.get(id);
  }

  async getAllCompanyDocuments(): Promise<CompanyDocument[]> {
    return Array.from(this.companyDocuments.values()).sort((a, b) => 
      new Date(b.uploadedAt).getTime() - new Date(a.uploadedAt).getTime()
    );
  }

  async getCompanyDocumentsByCategory(category: string): Promise<CompanyDocument[]> {
    return Array.from(this.companyDocuments.values())
      .filter(doc => doc.category === category)
      .sort((a, b) => new Date(b.uploadedAt).getTime() - new Date(a.uploadedAt).getTime());
  }

  async createCompanyDocument(doc: InsertCompanyDocument): Promise<CompanyDocument> {
    const id = this.currentId++;
    const companyDocument: CompanyDocument = {
      ...doc,
      id,
      uploadedAt: new Date(),
    };
    this.companyDocuments.set(id, companyDocument);
    return companyDocument;
  }

  async deleteCompanyDocument(id: number): Promise<boolean> {
    return this.companyDocuments.delete(id);
  }

  // RFP Responses
  async getRfpResponse(id: number): Promise<RfpResponse | undefined> {
    return this.rfpResponses.get(id);
  }

  async getAllRfpResponses(): Promise<RfpResponse[]> {
    return Array.from(this.rfpResponses.values()).sort((a, b) => 
      new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }

  async getRfpResponsesByRfpId(rfpDocumentId: number): Promise<RfpResponse[]> {
    return Array.from(this.rfpResponses.values())
      .filter(response => response.rfpDocumentId === rfpDocumentId)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  async createRfpResponse(response: InsertRfpResponse): Promise<RfpResponse> {
    const id = this.currentId++;
    const rfpResponse: RfpResponse = {
      ...response,
      id,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.rfpResponses.set(id, rfpResponse);
    return rfpResponse;
  }

  async updateRfpResponse(id: number, updates: Partial<RfpResponse>): Promise<RfpResponse | undefined> {
    const existing = this.rfpResponses.get(id);
    if (!existing) return undefined;
    
    const updated = { ...existing, ...updates, updatedAt: new Date() };
    this.rfpResponses.set(id, updated);
    return updated;
  }

  async deleteRfpResponse(id: number): Promise<boolean> {
    return this.rfpResponses.delete(id);
  }

  // Templates
  async getTemplate(id: number): Promise<Template | undefined> {
    return this.templates.get(id);
  }

  async getAllTemplates(): Promise<Template[]> {
    return Array.from(this.templates.values()).sort((a, b) => 
      new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }

  async getTemplatesByCategory(category: string): Promise<Template[]> {
    return Array.from(this.templates.values())
      .filter(template => template.category === category)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  async createTemplate(template: InsertTemplate): Promise<Template> {
    const id = this.currentId++;
    const newTemplate: Template = {
      ...template,
      id,
      createdAt: new Date(),
    };
    this.templates.set(id, newTemplate);
    return newTemplate;
  }

  async updateTemplate(id: number, updates: Partial<Template>): Promise<Template | undefined> {
    const existing = this.templates.get(id);
    if (!existing) return undefined;
    
    const updated = { ...existing, ...updates };
    this.templates.set(id, updated);
    return updated;
  }

  async deleteTemplate(id: number): Promise<boolean> {
    return this.templates.delete(id);
  }

  // Branding Settings
  async getBrandingSettings(): Promise<BrandingSettings | undefined> {
    return this.brandingSettings;
  }

  async updateBrandingSettings(settings: InsertBrandingSettings): Promise<BrandingSettings> {
    this.brandingSettings = {
      id: 1,
      ...settings,
      updatedAt: new Date(),
    };
    return this.brandingSettings;
  }
}

// DatabaseStorage implementation
export class DatabaseStorage implements IStorage {
  async getRfpDocument(id: number): Promise<RfpDocument | undefined> {
    const [document] = await db.select().from(rfpDocuments).where(eq(rfpDocuments.id, id));
    return document || undefined;
  }

  async getAllRfpDocuments(): Promise<RfpDocument[]> {
    return await db.select().from(rfpDocuments).orderBy(desc(rfpDocuments.uploadedAt));
  }

  async createRfpDocument(doc: InsertRfpDocument): Promise<RfpDocument> {
    const [document] = await db.insert(rfpDocuments).values({
      ...doc,
      content: doc.content || null,
      status: doc.status || "uploaded",
    }).returning();
    return document;
  }

  async updateRfpDocument(id: number, updates: Partial<RfpDocument>): Promise<RfpDocument | undefined> {
    const [document] = await db.update(rfpDocuments)
      .set(updates)
      .where(eq(rfpDocuments.id, id))
      .returning();
    return document || undefined;
  }

  async deleteRfpDocument(id: number): Promise<boolean> {
    const result = await db.delete(rfpDocuments).where(eq(rfpDocuments.id, id));
    return (result.rowCount || 0) > 0;
  }

  // Company Documents
  async getCompanyDocument(id: number): Promise<CompanyDocument | undefined> {
    const [document] = await db.select().from(companyDocuments).where(eq(companyDocuments.id, id));
    return document || undefined;
  }

  async getAllCompanyDocuments(): Promise<CompanyDocument[]> {
    return await db.select().from(companyDocuments).orderBy(desc(companyDocuments.uploadedAt));
  }

  async getCompanyDocumentsByCategory(category: string): Promise<CompanyDocument[]> {
    return await db.select().from(companyDocuments)
      .where(eq(companyDocuments.category, category))
      .orderBy(desc(companyDocuments.uploadedAt));
  }

  async createCompanyDocument(doc: InsertCompanyDocument): Promise<CompanyDocument> {
    const [document] = await db.insert(companyDocuments).values({
      ...doc,
      content: doc.content || null,
    }).returning();
    return document;
  }

  async deleteCompanyDocument(id: number): Promise<boolean> {
    const result = await db.delete(companyDocuments).where(eq(companyDocuments.id, id));
    return (result.rowCount || 0) > 0;
  }

  // RFP Responses
  async getRfpResponse(id: number): Promise<RfpResponse | undefined> {
    const [response] = await db.select().from(rfpResponses).where(eq(rfpResponses.id, id));
    return response || undefined;
  }

  async getAllRfpResponses(): Promise<RfpResponse[]> {
    return await db.select().from(rfpResponses).orderBy(desc(rfpResponses.createdAt));
  }

  async getRfpResponsesByRfpId(rfpDocumentId: number): Promise<RfpResponse[]> {
    return await db.select().from(rfpResponses)
      .where(eq(rfpResponses.rfpDocumentId, rfpDocumentId))
      .orderBy(desc(rfpResponses.createdAt));
  }

  async createRfpResponse(response: InsertRfpResponse): Promise<RfpResponse> {
    const [newResponse] = await db.insert(rfpResponses).values({
      ...response,
      content: response.content || null,
      status: response.status || "draft",
    }).returning();
    return newResponse;
  }

  async updateRfpResponse(id: number, updates: Partial<RfpResponse>): Promise<RfpResponse | undefined> {
    const [response] = await db.update(rfpResponses)
      .set(updates)
      .where(eq(rfpResponses.id, id))
      .returning();
    return response || undefined;
  }

  async deleteRfpResponse(id: number): Promise<boolean> {
    const result = await db.delete(rfpResponses).where(eq(rfpResponses.id, id));
    return (result.rowCount || 0) > 0;
  }

  // Templates
  async getTemplate(id: number): Promise<Template | undefined> {
    const [template] = await db.select().from(templates).where(eq(templates.id, id));
    return template || undefined;
  }

  async getAllTemplates(): Promise<Template[]> {
    return await db.select().from(templates).orderBy(desc(templates.createdAt));
  }

  async getTemplatesByCategory(category: string): Promise<Template[]> {
    return await db.select().from(templates)
      .where(eq(templates.category, category))
      .orderBy(desc(templates.createdAt));
  }

  async createTemplate(template: InsertTemplate): Promise<Template> {
    const [newTemplate] = await db.insert(templates).values({
      ...template,
      description: template.description || null,
    }).returning();
    return newTemplate;
  }

  async updateTemplate(id: number, updates: Partial<Template>): Promise<Template | undefined> {
    const [template] = await db.update(templates)
      .set(updates)
      .where(eq(templates.id, id))
      .returning();
    return template || undefined;
  }

  async deleteTemplate(id: number): Promise<boolean> {
    const result = await db.delete(templates).where(eq(templates.id, id));
    return (result.rowCount || 0) > 0;
  }

  // Branding Settings
  async getBrandingSettings(): Promise<BrandingSettings | undefined> {
    const [settings] = await db.select().from(brandingSettings).limit(1);
    if (!settings) {
      // Create default branding settings if none exist
      return await this.updateBrandingSettings({
        companyName: "Smart National Solutions",
        primaryColor: "#00D4ED",
        secondaryColor: "#00BCD4",
        fontFamily: "Roboto",
        logoUrl: null,
      });
    }
    return settings;
  }

  async updateBrandingSettings(settings: InsertBrandingSettings): Promise<BrandingSettings> {
    // Try to update existing settings first
    const [existing] = await db.select().from(brandingSettings).limit(1);
    
    if (existing) {
      const [updated] = await db.update(brandingSettings)
        .set({
          ...settings,
          logoUrl: settings.logoUrl !== undefined ? settings.logoUrl : existing.logoUrl,
          primaryColor: settings.primaryColor || existing.primaryColor,
          secondaryColor: settings.secondaryColor || existing.secondaryColor,
          fontFamily: settings.fontFamily || existing.fontFamily,
          updatedAt: new Date(),
        })
        .where(eq(brandingSettings.id, existing.id))
        .returning();
      return updated;
    } else {
      // Create new settings
      const [created] = await db.insert(brandingSettings).values({
        ...settings,
        logoUrl: settings.logoUrl || null,
        primaryColor: settings.primaryColor || "#00D4ED",
        secondaryColor: settings.secondaryColor || "#00BCD4",
        fontFamily: settings.fontFamily || "Roboto",
      }).returning();
      return created;
    }
  }
}

// Temporarily using MemStorage until Azure connection is fully configured
export const storage = new MemStorage();
