import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { azureAIService } from "./ai-service";
import { authService } from "./auth-service";
import { chatbotService } from "./chatbot-service";
import { insertUserSchema } from "@shared/schema";
import { 
  insertRfpDocumentSchema,
  insertCompanyDocumentSchema,
  insertRfpResponseSchema,
  insertTemplateSchema,
  insertBrandingSettingsSchema
} from "@shared/schema";
import multer from "multer";
import { z } from "zod";

// Configure multer for file uploads
const upload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 10 * 1024 * 1024, // 10MB limit
  },
  fileFilter: (req, file, cb) => {
    const allowedTypes = [
      'application/pdf',
      'application/msword',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    ];
    if (allowedTypes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error('Invalid file type. Only PDF and Word documents are allowed.'));
    }
  },
});

// Authentication middleware
const authenticateToken = async (req: any, res: any, next: any) => {
  const token = req.headers.authorization?.split(' ')[1]; // Bearer TOKEN
  
  if (!token) {
    return res.status(401).json({ message: 'Access token required' });
  }

  try {
    const user = await authService.verifySession(token);
    if (!user) {
      return res.status(401).json({ message: 'Invalid or expired token' });
    }
    
    req.user = user;
    next();
  } catch (error) {
    return res.status(401).json({ message: 'Token verification failed' });
  }
};

export async function registerRoutes(app: Express): Promise<Server> {
  // Health check endpoint for deployment monitoring
  app.get("/api/health", async (req, res) => {
    try {
      // Test database connection
      const dbTest = await storage.getAllRfpDocuments();
      
      // Test Azure AI connection
      const aiTest = await azureAIService.testConnection();
      
      const health = {
        status: "healthy",
        timestamp: new Date().toISOString(),
        version: "1.0.0",
        services: {
          database: Array.isArray(dbTest) ? "connected" : "disconnected",
          azureAI: aiTest ? "connected" : "disconnected"
        },
        environment: process.env.NODE_ENV || "development"
      };
      
      res.json(health);
    } catch (error) {
      res.status(500).json({
        status: "unhealthy",
        timestamp: new Date().toISOString(),
        error: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  // Authentication routes
  app.post("/api/auth/register", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      const result = await authService.register(userData);
      
      if (result.success) {
        res.status(201).json(result);
      } else {
        res.status(400).json(result);
      }
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ success: false, message: "Invalid input data", errors: error.errors });
      } else {
        res.status(500).json({ success: false, message: "Registration failed" });
      }
    }
  });

  app.post("/api/auth/verify-email", async (req, res) => {
    try {
      const { token } = req.body;
      
      if (!token) {
        return res.status(400).json({ success: false, message: "Verification token required" });
      }

      const result = await authService.verifyEmail(token);
      
      if (result.success) {
        res.status(200).json(result);
      } else {
        res.status(400).json(result);
      }
    } catch (error) {
      res.status(500).json({ success: false, message: "Email verification failed" });
    }
  });

  app.post("/api/auth/set-password", async (req, res) => {
    try {
      const { userId, password } = req.body;
      
      if (!userId || !password) {
        return res.status(400).json({ success: false, message: "User ID and password required" });
      }

      if (password.length < 6) {
        return res.status(400).json({ success: false, message: "Password must be at least 6 characters long" });
      }

      const result = await authService.setPassword(userId, password);
      
      if (result.success) {
        res.status(200).json(result);
      } else {
        res.status(400).json(result);
      }
    } catch (error) {
      res.status(500).json({ success: false, message: "Failed to set password" });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    try {
      const { email, password } = req.body;
      
      if (!email || !password) {
        return res.status(400).json({ success: false, message: "Email and password required" });
      }

      const result = await authService.login(email, password);
      
      if (result.success) {
        res.status(200).json(result);
      } else {
        res.status(400).json(result);
      }
    } catch (error) {
      res.status(500).json({ success: false, message: "Login failed" });
    }
  });

  app.post("/api/auth/logout", authenticateToken, async (req, res) => {
    try {
      const token = req.headers.authorization?.split(' ')[1];
      
      if (token) {
        await authService.logout(token);
      }
      
      res.status(200).json({ success: true, message: "Logged out successfully" });
    } catch (error) {
      res.status(500).json({ success: false, message: "Logout failed" });
    }
  });

  app.get("/api/auth/me", authenticateToken, async (req, res) => {
    try {
      res.status(200).json({ success: true, user: req.user });
    } catch (error) {
      res.status(500).json({ success: false, message: "Failed to get user data" });
    }
  });

  // Email verification via URL (GET request)
  app.get("/verify-email", async (req, res) => {
    try {
      const { token } = req.query;
      
      if (!token || typeof token !== 'string') {
        return res.redirect('/?error=invalid_token');
      }

      const result = await authService.verifyEmail(token);
      
      if (result.success) {
        // Redirect to set password page with user ID
        return res.redirect(`/set-password?userId=${result.userId}`);
      } else {
        return res.redirect(`/?error=verification_failed&message=${encodeURIComponent(result.message)}`);
      }
    } catch (error) {
      return res.redirect('/?error=verification_error');
    }
  });

  // RFP Documents routes
  app.get("/api/rfp-documents", async (req, res) => {
    try {
      const documents = await storage.getAllRfpDocuments();
      res.json(documents);
    } catch (error) {
      console.error("Error fetching RFP documents:", error);
      res.status(500).json({ message: "Failed to fetch RFP documents" });
    }
  });

  app.get("/api/rfp-documents/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const document = await storage.getRfpDocument(id);
      if (!document) {
        return res.status(404).json({ message: "RFP document not found" });
      }
      res.json(document);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch RFP document" });
    }
  });

  app.post("/api/rfp-documents", upload.single('file'), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }

      const { title, clientName } = req.body;
      if (!title || !clientName) {
        return res.status(400).json({ message: "Title and client name are required" });
      }

      // Extract text content from file (simplified - in production use PDF-parse or similar)
      const content = req.file.buffer.toString('utf-8').slice(0, 1000); // Basic text extraction

      // Properly decode Arabic filename
      let decodedFileName = req.file.originalname;
      try {
        // Handle UTF-8 encoded filenames
        decodedFileName = Buffer.from(req.file.originalname, 'latin1').toString('utf8');
      } catch (error) {
        // Fallback to original filename if decoding fails
        decodedFileName = req.file.originalname;
      }

      const documentData = {
        title,
        clientName,
        fileName: decodedFileName,
        fileSize: req.file.size,
        fileType: req.file.mimetype,
        content,
        status: "processing",
      };

      const validated = insertRfpDocumentSchema.parse(documentData);
      const document = await storage.createRfpDocument(validated);

      // Simulate processing delay
      setTimeout(async () => {
        await storage.updateRfpDocument(document.id, {
          status: "processed",
          processedAt: new Date(),
        });
      }, 2000);

      res.status(201).json(document);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid document data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to upload RFP document" });
    }
  });

  app.delete("/api/rfp-documents/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const deleted = await storage.deleteRfpDocument(id);
      if (!deleted) {
        return res.status(404).json({ message: "RFP document not found" });
      }
      res.json({ message: "RFP document deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete RFP document" });
    }
  });

  // Company Documents routes
  app.get("/api/company-documents", async (req, res) => {
    try {
      const { category } = req.query;
      let documents;
      if (category && typeof category === 'string') {
        documents = await storage.getCompanyDocumentsByCategory(category);
      } else {
        documents = await storage.getAllCompanyDocuments();
      }
      res.json(documents);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch company documents" });
    }
  });

  app.post("/api/company-documents", upload.single('file'), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }

      const { title, category } = req.body;
      if (!title || !category) {
        return res.status(400).json({ message: "Title and category are required" });
      }

      const content = req.file.buffer.toString('utf-8').slice(0, 1000);

      const documentData = {
        title,
        category,
        fileName: req.file.originalname,
        fileSize: req.file.size,
        fileType: req.file.mimetype,
        content,
      };

      const validated = insertCompanyDocumentSchema.parse(documentData);
      const document = await storage.createCompanyDocument(validated);

      res.status(201).json(document);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid document data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to upload company document" });
    }
  });

  app.delete("/api/company-documents/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const deleted = await storage.deleteCompanyDocument(id);
      if (!deleted) {
        return res.status(404).json({ message: "Company document not found" });
      }
      res.json({ message: "Company document deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete company document" });
    }
  });

  // RFP Responses routes
  app.get("/api/rfp-responses", async (req, res) => {
    try {
      const { rfpDocumentId } = req.query;
      let responses;
      if (rfpDocumentId && typeof rfpDocumentId === 'string') {
        responses = await storage.getRfpResponsesByRfpId(parseInt(rfpDocumentId));
      } else {
        responses = await storage.getAllRfpResponses();
      }
      res.json(responses);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch RFP responses" });
    }
  });

  app.post("/api/rfp-responses", async (req, res) => {
    try {
      const validated = insertRfpResponseSchema.parse(req.body);
      const response = await storage.createRfpResponse(validated);
      res.status(201).json(response);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid response data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create RFP response" });
    }
  });

  app.put("/api/rfp-responses/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updates = req.body;
      const response = await storage.updateRfpResponse(id, updates);
      if (!response) {
        return res.status(404).json({ message: "RFP response not found" });
      }
      res.json(response);
    } catch (error) {
      res.status(500).json({ message: "Failed to update RFP response" });
    }
  });

  // Update RFP response pricing
  app.put("/api/rfp-responses/:id/pricing", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const pricingData = req.body;
      
      // Calculate totals
      const projectDurationMonths = parseFloat(pricingData.projectDurationMonths) || 0;
      const numberOfConsultants = parseFloat(pricingData.numberOfConsultants) || 0;
      const pricePerConsultantPerMonth = parseFloat(pricingData.pricePerConsultantPerMonth) || 0;
      const taxRate = parseFloat(pricingData.taxRate) || 0;
      
      // Calculate consultant costs
      let consultantCosts = 0;
      if (pricingData.consultantTypes && Array.isArray(pricingData.consultantTypes)) {
        consultantCosts = pricingData.consultantTypes.reduce((total: number, type: any) => {
          const count = parseFloat(type.count) || 0;
          const rate = parseFloat(type.rate) || 0;
          return total + (count * rate * projectDurationMonths);
        }, 0);
      }
      
      // Fallback to simple calculation
      if (consultantCosts === 0) {
        consultantCosts = projectDurationMonths * numberOfConsultants * pricePerConsultantPerMonth;
      }
      
      // Add additional costs
      let additionalCosts = 0;
      if (pricingData.additionalCosts && Array.isArray(pricingData.additionalCosts)) {
        additionalCosts = pricingData.additionalCosts.reduce((total: number, cost: any) => {
          return total + (parseFloat(cost.cost) || 0);
        }, 0);
      }
      
      const totalProjectCost = consultantCosts + additionalCosts;
      const taxAmount = (totalProjectCost * taxRate) / 100;
      const finalTotalCost = totalProjectCost + taxAmount;
      
      const updates = {
        projectDurationMonths,
        numberOfConsultants,
        pricePerConsultantPerMonth: pricePerConsultantPerMonth.toString(),
        totalProjectCost: totalProjectCost.toString(),
        taxRate: taxRate.toString(),
        taxAmount: taxAmount.toString(),
        finalTotalCost: finalTotalCost.toString(),
        deliveryModel: pricingData.deliveryModel,
        consultantTypes: JSON.stringify(pricingData.consultantTypes || []),
        additionalCosts: JSON.stringify(pricingData.additionalCosts || []),
        paymentTerms: pricingData.paymentTerms,
        proposalValidityDays: parseInt(pricingData.proposalValidityDays) || 30,
      };
      
      const response = await storage.updateRfpResponse(id, updates);
      if (!response) {
        return res.status(404).json({ message: "RFP response not found" });
      }
      res.json(response);
    } catch (error) {
      console.error("Failed to update pricing:", error);
      res.status(500).json({ message: "Failed to update pricing" });
    }
  });

  // Templates routes
  app.get("/api/templates", async (req, res) => {
    try {
      const { category } = req.query;
      let templates;
      if (category && typeof category === 'string') {
        templates = await storage.getTemplatesByCategory(category);
      } else {
        templates = await storage.getAllTemplates();
      }
      res.json(templates);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch templates" });
    }
  });

  app.post("/api/templates", async (req, res) => {
    try {
      const validated = insertTemplateSchema.parse(req.body);
      const template = await storage.createTemplate(validated);
      res.status(201).json(template);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid template data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create template" });
    }
  });

  app.put("/api/templates/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updates = req.body;
      const template = await storage.updateTemplate(id, updates);
      if (!template) {
        return res.status(404).json({ message: "Template not found" });
      }
      res.json(template);
    } catch (error) {
      res.status(500).json({ message: "Failed to update template" });
    }
  });

  app.delete("/api/templates/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const deleted = await storage.deleteTemplate(id);
      if (!deleted) {
        return res.status(404).json({ message: "Template not found" });
      }
      res.json({ message: "Template deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete template" });
    }
  });

  // Branding Settings routes
  app.get("/api/branding-settings", async (req, res) => {
    try {
      const settings = await storage.getBrandingSettings();
      res.json(settings);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch branding settings" });
    }
  });

  app.put("/api/branding-settings", async (req, res) => {
    try {
      const validated = insertBrandingSettingsSchema.parse(req.body);
      const settings = await storage.updateBrandingSettings(validated);
      res.json(settings);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid branding data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update branding settings" });
    }
  });

  // Stats endpoint for dashboard
  app.get("/api/stats", async (req, res) => {
    try {
      const rfpDocuments = await storage.getAllRfpDocuments();
      const rfpResponses = await storage.getAllRfpResponses();
      const templates = await storage.getAllTemplates();

      const stats = {
        totalRfps: rfpDocuments.length,
        completed: rfpResponses.filter(r => r.status === "completed").length,
        inProgress: rfpResponses.filter(r => r.status === "draft" || r.status === "in-progress").length,
        templates: templates.length,
      };

      res.json(stats);
    } catch (error) {
      console.error("Error fetching stats:", error);
      res.status(500).json({ message: "Failed to fetch stats" });
    }
  });

  // Test Azure AI connection
  app.get("/api/ai/test", async (req, res) => {
    try {
      // Test chatbot service functionality as primary indicator
      let isChatbotWorking = false;
      try {
        const testResponse = await chatbotService.processMessage({
          message: 'test',
          context: 'test',
          conversation_history: []
        });
        isChatbotWorking = !!testResponse.content;
      } catch (error) {
        console.log("Chatbot test failed:", error);
      }
      
      const isAIServiceConnected = await azureAIService.testConnection();
      const isConnected = isChatbotWorking || isAIServiceConnected;
      
      res.json({ 
        connected: isConnected,
        service: "Azure AI Foundry",
        status: isConnected ? "online" : "offline",
        details: {
          chatbot: isChatbotWorking ? "operational" : "offline",
          analysis: isAIServiceConnected ? "operational" : "offline"
        }
      });
    } catch (error) {
      console.error("AI connection test error:", error);
      res.status(500).json({ 
        connected: false,
        service: "Azure AI Foundry",
        status: "error",
        message: "Connection test failed"
      });
    }
  });

  // Analyze RFP Document with AI
  app.post("/api/rfp-documents/:id/analyze", async (req, res) => {
    try {
      const rfpDocument = await storage.getRfpDocument(parseInt(req.params.id));
      if (!rfpDocument) {
        return res.status(404).json({ message: "RFP document not found" });
      }

      const analysis = await azureAIService.analyzeRfpDocument(rfpDocument);
      
      // Update RFP document with analysis results
      await storage.updateRfpDocument(rfpDocument.id, {
        status: "analyzed",
        processedAt: new Date()
      });

      res.json(analysis);
    } catch (error) {
      console.error("Error analyzing RFP document:", error);
      res.status(500).json({ message: "Failed to analyze RFP document" });
    }
  });

  // Generate document summary endpoint
  app.post("/api/documents/:id/summary", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const rfpDocument = await storage.getRfpDocument(id);
      
      if (!rfpDocument) {
        return res.status(404).json({ message: "Document not found" });
      }

      if (rfpDocument.status !== "processed") {
        return res.status(400).json({ message: "Document must be processed before generating summary" });
      }

      // Generate AI summary using Azure AI
      const summaryPrompt = `Analyze this RFP document and extract key information in the same language as the document content. Provide a structured summary with these sections:

**📋 SUBMISSION DETAILS:**
- Deadline: [Extract submission deadline/due date]
- Contact: [Key contact person or department]

**🎯 KEY REQUIREMENTS:**
- [List 3-4 main project requirements or deliverables]

**📅 IMPORTANT DATES:**
- [Any mentioned project timelines, start dates, milestones]

**💰 BUDGET/VALUE:**
- [Any mentioned budget range or project value]

**🔧 TECHNICAL SPECS:**
- [Key technical requirements or specifications]

**📝 EVALUATION CRITERIA:**
- [How proposals will be evaluated, if mentioned]

Document Title: ${rfpDocument.title}
Client: ${rfpDocument.clientName}
Content: ${rfpDocument.content?.substring(0, 4000)}...

Keep the response concise but comprehensive. If information is not available, note "Not specified".]`;

      try {
        const response = await fetch(`${process.env.AZURE_AI_ENDPOINT}/openai/deployments/${process.env.AZURE_AI_DEPLOYMENT_NAME}/chat/completions?api-version=2024-02-15-preview`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'api-key': process.env.AZURE_AI_API_KEY!,
          },
          body: JSON.stringify({
            messages: [
              {
                role: 'system',
                content: 'You are an expert document analyzer. Provide clear, professional summaries that capture the essence of RFP documents.'
              },
              {
                role: 'user',
                content: summaryPrompt
              }
            ],
            max_tokens: 500,
            temperature: 0.3
          })
        });

        if (!response.ok) {
          throw new Error(`Azure AI API error: ${response.status}`);
        }

        const aiResponse = await response.json();
        const summary = aiResponse.choices[0]?.message?.content || "Unable to generate summary at this time.";

        res.json({ summary });
      } catch (aiError) {
        console.error('Azure AI summary error:', aiError);
        // Enhanced fallback summary with structured information
        const content = rfpDocument.content || "";
        
        // Extract potential dates from content
        const dateRegex = /(\d{1,2}[-\/]\d{1,2}[-\/]\d{2,4}|\d{4}[-\/]\d{1,2}[-\/]\d{1,2}|January|February|March|April|May|June|July|August|September|October|November|December)/gi;
        const foundDates = content.match(dateRegex)?.slice(0, 3).join(", ") || "Not specified";
        
        // Extract potential budget/value mentions
        const budgetRegex = /(\$[\d,]+|USD\s*[\d,]+|SAR\s*[\d,]+|EUR\s*[\d,]+|budget|cost|value|price)/gi;
        const foundBudget = content.match(budgetRegex)?.slice(0, 2).join(", ") || "Not specified";
        
        const fallbackSummary = `
**📋 SUBMISSION DETAILS:**
- Document: ${rfpDocument.title}
- Client: ${rfpDocument.clientName}
- Upload Date: ${new Date(rfpDocument.uploadedAt).toLocaleDateString()}

**📅 IMPORTANT DATES:**
- Found Dates: ${foundDates}

**💰 BUDGET/VALUE:**
- Budget References: ${foundBudget}

**🎯 KEY REQUIREMENTS:**
- Document contains project requirements and specifications for proposal submission
- Full analysis requires processing of document content

**📝 STATUS:**
- Document processed and ready for detailed AI analysis
- Content length: ${content.length} characters`;
        
        res.json({ summary: fallbackSummary });
      }
    } catch (error) {
      console.error("Error generating document summary:", error);
      res.status(500).json({ message: "Failed to generate summary" });
    }
  });

  // Generate RFP Response endpoint with AI
  app.post("/api/generate-response", async (req, res) => {
    try {
      const { rfpDocumentId, templateIds = [] } = req.body;
      
      if (!rfpDocumentId) {
        return res.status(400).json({ message: "RFP document ID is required" });
      }

      const rfpDocument = await storage.getRfpDocument(rfpDocumentId);
      if (!rfpDocument) {
        return res.status(404).json({ message: "RFP document not found" });
      }

      // Get all company documents and specified templates
      const companyDocuments = await storage.getAllCompanyDocuments();
      const templates = templateIds.length > 0 
        ? await Promise.all(templateIds.map((id: number) => storage.getTemplate(id)))
        : await storage.getAllTemplates();
      
      const validTemplates = templates.filter(Boolean);

      // First analyze the RFP if not already done
      const analysis = await azureAIService.analyzeRfpDocument(rfpDocument);

      // Generate AI-powered response
      const generatedResponse = await azureAIService.generateResponse(
        rfpDocument,
        companyDocuments,
        validTemplates,
        analysis
      );

      // Create and save the response
      const rfpResponse = await storage.createRfpResponse({
        rfpDocumentId: rfpDocument.id,
        title: `Response to ${rfpDocument.title}`,
        content: generatedResponse.content,
        status: "draft"
      });

      res.json({
        response: rfpResponse,
        analysis,
        generatedResponse: {
          confidence: generatedResponse.confidence,
          usedDocuments: generatedResponse.usedDocuments,
          usedTemplates: generatedResponse.usedTemplates,
          recommendations: generatedResponse.recommendations
        }
      });
    } catch (error) {
      console.error("Error generating response:", error);
      res.status(500).json({ message: "Failed to generate response" });
    }
  });

  // Legacy generate response endpoint (keeping for backward compatibility)
  app.post("/api/generate-response-simple", async (req, res) => {
    try {
      const { rfpDocumentId, templateId } = req.body;
      
      if (!rfpDocumentId) {
        return res.status(400).json({ message: "RFP document ID is required" });
      }

      const rfpDocument = await storage.getRfpDocument(rfpDocumentId);
      if (!rfpDocument) {
        return res.status(404).json({ message: "RFP document not found" });
      }

      let template;
      if (templateId) {
        template = await storage.getTemplate(templateId);
        if (!template) {
          return res.status(404).json({ message: "Template not found" });
        }
      }

      // Generate simple response content
      const responseContent = `
        Dear ${rfpDocument.clientName},
        
        Thank you for your interest in Smart National Solutions regarding "${rfpDocument.title}".
        
        ${template ? template.content : "We are pleased to provide our response to your RFP."}
        
        Based on our analysis of your requirements, we propose the following solution:
        
        1. Project Overview
        2. Technical Approach
        3. Timeline and Deliverables
        4. Pricing Structure
        5. Team Qualifications
        
        We look forward to discussing this opportunity with you further.
        
        Best regards,
        Smart National Solutions Team
      `;

      const responseData = {
        rfpDocumentId,
        title: `Response to ${rfpDocument.title}`,
        content: responseContent,
        status: "draft",
      };

      const response = await storage.createRfpResponse(responseData);
      res.status(201).json(response);
    } catch (error) {
      res.status(500).json({ message: "Failed to generate RFP response" });
    }
  });

  // Chatbot routes
  app.post("/api/chatbot/message", async (req, res) => {
    try {
      const { message, context, conversation_history } = req.body;
      
      if (!message) {
        return res.status(400).json({ message: "Message is required" });
      }

      const response = await chatbotService.processMessage({
        message,
        context: context || 'general',
        conversation_history: conversation_history || []
      });

      res.json(response);
    } catch (error) {
      console.error('Chatbot API error:', error);
      res.status(500).json({ 
        content: "I apologize, but I'm experiencing technical difficulties right now. Please try again in a moment.",
        message: "Failed to process chatbot message" 
      });
    }
  });

  app.get("/api/chatbot/status", async (req, res) => {
    try {
      const isConnected = await chatbotService.testConnection();
      const hasCredentials = !!(process.env.AZURE_AI_ENDPOINT && process.env.AZURE_AI_API_KEY);
      
      res.json({ 
        status: isConnected ? 'connected' : 'disconnected',
        service: 'Azure AI Foundry',
        credentials_configured: hasCredentials,
        endpoint_configured: !!process.env.AZURE_AI_ENDPOINT,
        api_key_configured: !!process.env.AZURE_AI_API_KEY,
        diagnostic_info: {
          endpoint_format: process.env.AZURE_AI_ENDPOINT ? 'configured' : 'missing',
          suggestion: 'If getting 404 errors, check deployment name. Common deployment names: gpt-4, gpt-35-turbo, gpt-4o'
        }
      });
    } catch (error) {
      res.status(500).json({ 
        status: 'error',
        service: 'Azure AI Foundry',
        error: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });

  app.post("/api/ai/test-deployments", async (req, res) => {
    try {
      const endpoint = process.env.AZURE_AI_ENDPOINT;
      const apiKey = process.env.AZURE_AI_API_KEY;
      
      if (!endpoint || !apiKey) {
        return res.status(400).json({ error: 'Azure AI credentials not configured' });
      }

      const commonDeployments = ['gpt-4', 'gpt-35-turbo', 'gpt-4o', 'gpt-4-turbo'];
      const apiVersions = ['2024-08-01-preview', '2024-02-15-preview', '2023-12-01-preview'];
      
      const results = [];
      
      for (const deployment of commonDeployments) {
        for (const apiVersion of apiVersions) {
          try {
            const testUrl = `${endpoint}/openai/deployments/${deployment}/chat/completions?api-version=${apiVersion}`;
            const response = await fetch(testUrl, {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
                'api-key': apiKey
              },
              body: JSON.stringify({
                messages: [{ role: 'user', content: 'test' }],
                max_tokens: 5
              })
            });
            
            results.push({
              deployment,
              apiVersion,
              status: response.status,
              success: response.ok,
              url: testUrl
            });
            
            if (response.ok) {
              // Found a working configuration, break early
              break;
            }
          } catch (error) {
            results.push({
              deployment,
              apiVersion,
              status: 'error',
              success: false,
              error: error instanceof Error ? error.message : 'Unknown error'
            });
          }
        }
      }
      
      res.json({ results });
    } catch (error) {
      res.status(500).json({ error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  // AI Content Editing endpoints
  app.post("/api/ai/edit-content", async (req, res) => {
    try {
      const { originalContent, instruction, section } = req.body;
      
      if (!originalContent || !instruction) {
        return res.status(400).json({ message: "Original content and instruction are required" });
      }

      const editResponse = await azureAIService.editContent({
        originalContent,
        instruction,
        section
      });

      res.json(editResponse);
    } catch (error) {
      console.error("Content editing error:", error);
      res.status(500).json({ 
        message: "Failed to edit content",
        error: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });

  // Visual Content Generation endpoints
  app.post("/api/ai/generate-visual", async (req, res) => {
    try {
      const { description, type } = req.body;
      
      if (!description || !type) {
        return res.status(400).json({ message: "Description and type are required" });
      }

      const visualContent = await azureAIService.generateVisualContent(description, type);
      res.json(visualContent);
    } catch (error) {
      console.error("Visual content generation error:", error);
      res.status(500).json({ 
        message: "Failed to generate visual content",
        error: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });

  // Get branding assets (from uploaded presentations)
  app.get("/api/branding/assets", async (req, res) => {
    try {
      const brandingSettings = await storage.getBrandingSettings();
      
      if (!brandingSettings || !brandingSettings.presentationUrl) {
        return res.json({ assets: [] });
      }

      // Mock branding assets for now - in a real implementation,
      // you would extract these from the uploaded PPTX file
      const mockAssets = [
        {
          type: 'logo',
          title: 'SNS Primary Logo',
          description: 'Main company logo in light blue',
          url: '/assets/sns-logo-light.png'
        },
        {
          type: 'logo',
          title: 'SNS Secondary Logo',
          description: 'Alternative logo in royal blue',
          url: '/assets/sns-logo-royal.png'
        },
        {
          type: 'infographic',
          title: 'Service Architecture Diagram',
          description: 'Technical architecture overview infographic',
          url: '/assets/architecture-diagram.png'
        },
        {
          type: 'image',
          title: 'Team Collaboration',
          description: 'Professional team working together',
          url: '/assets/team-collaboration.png'
        },
        {
          type: 'chart',
          title: 'Performance Metrics',
          description: 'Key performance indicators chart',
          url: '/assets/performance-chart.png'
        }
      ];

      res.json({ assets: mockAssets });
    } catch (error) {
      console.error("Error fetching branding assets:", error);
      res.status(500).json({ message: "Failed to fetch branding assets" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
