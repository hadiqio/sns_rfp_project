interface ChatMessage {
  id: string;
  type: 'user' | 'bot';
  content: string;
  timestamp: Date;
  attachments?: {
    type: 'image' | 'table' | 'navigation';
    data: any;
  }[];
}

interface ChatbotRequest {
  message: string;
  context: string;
  conversation_history: ChatMessage[];
}

interface ChatbotResponse {
  content: string;
  attachments?: {
    type: 'image' | 'table' | 'navigation';
    data: any;
  }[];
}

class ChatbotService {
  private endpoint: string;
  private apiKey: string;

  constructor() {
    this.endpoint = process.env.AZURE_AI_ENDPOINT || '';
    this.apiKey = process.env.AZURE_AI_API_KEY || '';
  }

  async processMessage(request: ChatbotRequest): Promise<ChatbotResponse> {
    try {
      // Check if the message is asking for navigation help
      if (this.isNavigationQuery(request.message)) {
        return this.generateNavigationResponse(request.message);
      }

      // Check if the message is asking for table generation
      if (this.isTableQuery(request.message)) {
        return this.generateTableResponse(request.message);
      }

      // Check if the message is asking for image generation
      if (this.isImageQuery(request.message)) {
        return await this.generateImageResponse(request.message);
      }

      // For general RFP content generation and questions
      return await this.generateAIResponse(request);

    } catch (error) {
      console.error('Chatbot service error:', error);
      return {
        content: 'I apologize, but I\'m experiencing technical difficulties right now. Please try again in a moment or contact support if the issue persists.'
      };
    }
  }

  private isNavigationQuery(message: string): boolean {
    const navigationKeywords = ['navigate', 'navigation', 'where', 'how to get', 'find page', 'go to', 'menu', 'sidebar'];
    return navigationKeywords.some(keyword => message.toLowerCase().includes(keyword));
  }

  private isTableQuery(message: string): boolean {
    const tableKeywords = ['table', 'create table', 'build table', 'generate table', 'spreadsheet', 'rows', 'columns'];
    return tableKeywords.some(keyword => message.toLowerCase().includes(keyword));
  }

  private isImageQuery(message: string): boolean {
    const imageKeywords = ['image', 'picture', 'generate image', 'create image', 'visual', 'diagram', 'chart'];
    return imageKeywords.some(keyword => message.toLowerCase().includes(keyword));
  }

  private generateNavigationResponse(message: string): ChatbotResponse {
    const navigationHelp = {
      content: `Here's how to navigate the SNS RFP Generator:

**Main Sections:**
• **Dashboard** - Overview of your RFPs and statistics
• **Upload RFPs** - Upload new RFP documents to respond to
• **Company Data** - Manage your company documents and capabilities
• **Generate Response** - Create AI-powered RFP responses with pricing
• **Preview & Export** - Review and export your final proposals
• **SNS Branding** - Customize your brand presentation materials
• **Settings** - Configure system preferences

**Quick Actions:**
• Click "Upload New RFP" button on any page to start a new RFP response
• Use the sidebar navigation to move between sections
• Toggle between dark/light mode and English/Arabic using the top-right controls

What specific section would you like help with?`,
      attachments: [
        {
          type: 'navigation' as const,
          data: {
            sections: [
              { name: 'Dashboard', path: '/', description: 'Overview and statistics' },
              { name: 'Upload RFPs', path: '/upload-rfps', description: 'Upload RFP documents' },
              { name: 'Company Data', path: '/data-documents', description: 'Manage company documents' },
              { name: 'Generate Response', path: '/generate-response', description: 'AI-powered responses' },
              { name: 'Preview & Export', path: '/preview-export', description: 'Review proposals' },
              { name: 'SNS Branding', path: '/branding', description: 'Brand materials' },
              { name: 'Settings', path: '/settings', description: 'System preferences' }
            ]
          }
        }
      ]
    };

    return navigationHelp;
  }

  private generateTableResponse(message: string): ChatbotResponse {
    // Generate a sample table based on the context
    let tableData;
    
    if (message.toLowerCase().includes('pricing') || message.toLowerCase().includes('cost')) {
      tableData = {
        headers: ['Service', 'Duration (Months)', 'Consultants', 'Rate/Month', 'Total Cost'],
        rows: [
          ['Requirements Analysis', '2', '3', '$8,000', '$48,000'],
          ['System Design', '3', '4', '$10,000', '$120,000'],
          ['Development', '8', '6', '$12,000', '$576,000'],
          ['Testing & QA', '2', '3', '$8,000', '$48,000'],
          ['Deployment', '1', '2', '$10,000', '$20,000']
        ]
      };
    } else if (message.toLowerCase().includes('timeline') || message.toLowerCase().includes('schedule')) {
      tableData = {
        headers: ['Phase', 'Start Date', 'End Date', 'Duration', 'Deliverables'],
        rows: [
          ['Discovery', '2025-01-01', '2025-01-15', '2 weeks', 'Requirements Document'],
          ['Design', '2025-01-16', '2025-02-28', '6 weeks', 'Technical Specification'],
          ['Development', '2025-03-01', '2025-07-31', '5 months', 'Working System'],
          ['Testing', '2025-08-01', '2025-08-31', '1 month', 'Test Reports'],
          ['Deployment', '2025-09-01', '2025-09-15', '2 weeks', 'Live System']
        ]
      };
    } else {
      // Generic project structure table
      tableData = {
        headers: ['Component', 'Priority', 'Complexity', 'Estimated Hours', 'Dependencies'],
        rows: [
          ['User Authentication', 'High', 'Medium', '120', 'Database Setup'],
          ['Dashboard Analytics', 'High', 'High', '200', 'User Auth, Data Models'],
          ['Reporting Module', 'Medium', 'Medium', '150', 'Analytics'],
          ['Mobile App', 'Low', 'High', '300', 'API Development'],
          ['Third-party Integration', 'Medium', 'Low', '80', 'Core Features']
        ]
      };
    }

    return {
      content: 'I\'ve created a table based on your request. You can copy this data to include in your RFP response:',
      attachments: [
        {
          type: 'table' as const,
          data: tableData
        }
      ]
    };
  }

  private async generateImageResponse(message: string): Promise<ChatbotResponse> {
    // Since image generation with Azure AI requires more complex setup,
    // we'll provide a placeholder response for now
    return {
      content: 'I can help you generate images for your RFP proposals using Azure AI. However, image generation requires additional configuration. For now, I can suggest some alternatives:\n\n• Use professional stock images from your company library\n• Create charts and diagrams using the table generator\n• Consider adding technical architecture diagrams\n• Include process flow visualizations\n\nWould you like me to help you create a table or chart instead?'
    };
  }

  private async generateAIResponse(request: ChatbotRequest): Promise<ChatbotResponse> {
    if (!this.endpoint || !this.apiKey) {
      // Enhanced fallback responses based on content analysis
      if (request.message.toLowerCase().includes('pricing') || request.message.toLowerCase().includes('cost')) {
        return {
          content: 'I can help you structure RFP pricing! Here are key pricing strategies:\n\n• **Value-Based Pricing** - Price based on client outcomes and ROI\n• **Competitive Analysis** - Research market rates for similar services\n• **Phased Approach** - Break costs into project phases for clarity\n• **Risk Contingency** - Include 10-15% buffer for unforeseen costs\n• **Multiple Options** - Offer good/better/best tiers\n\nWould you like me to generate a sample pricing table for your RFP?'
        };
      }
      
      if (request.message.toLowerCase().includes('technical') || request.message.toLowerCase().includes('architecture')) {
        return {
          content: 'For technical RFP responses, consider these sections:\n\n• **System Architecture** - High-level technical design\n• **Technology Stack** - Programming languages, frameworks, databases\n• **Security Measures** - Data protection and compliance standards\n• **Scalability Plan** - How the solution grows with business needs\n• **Integration Points** - APIs and third-party connections\n• **Performance Metrics** - Expected response times and throughput\n\nWhat technical aspect needs the most detail in your response?'
        };
      }
      
      if (request.message.toLowerCase().includes('timeline') || request.message.toLowerCase().includes('schedule')) {
        return {
          content: 'Project timeline best practices for RFPs:\n\n• **Phase-Based Approach** - Break into discovery, design, development, testing\n• **Milestone Dependencies** - Show how phases connect and depend on each other\n• **Resource Allocation** - Map team members to specific timeline blocks\n• **Buffer Time** - Add 20% padding for unexpected challenges\n• **Client Review Points** - Schedule regular checkpoints for feedback\n\nShould I create a sample project timeline table for you?'
        };
      }
      
      return {
        content: 'I\'m your RFP assistant powered by Smart National Solutions expertise! I can help with:\n\n• **Content Writing** - Professional responses to RFP requirements\n• **Technical Specifications** - Detailed technical documentation\n• **Project Planning** - Timelines and resource allocation\n• **Pricing Strategies** - Competitive pricing models\n• **Table Generation** - Structured data for proposals\n\n*Note: Azure AI is currently offline. Enhanced AI features will be available once connected.*\n\nWhat specific aspect of your RFP needs assistance?'
      };
    }

    try {
      // Build conversation context
      const conversationContext = request.conversation_history
        .slice(-3) // Last 3 messages for context
        .map(msg => `${msg.type}: ${msg.content}`)
        .join('\n');

      const systemPrompt = `You are an AI assistant specialized in helping with RFP (Request for Proposal) responses. You work for Smart National Solutions (SNS), a technology consulting company. Your role is to:

1. Help users navigate the RFP platform
2. Generate professional RFP content
3. Provide technical expertise for proposals
4. Create structured responses to requirements
5. Suggest pricing and timeline strategies

Be professional, helpful, and focused on creating high-quality proposal content. Keep responses concise but comprehensive.

Recent conversation:
${conversationContext}

User question: ${request.message}`;

      // Try multiple potential deployment names
      const deploymentNames = ['gpt-4', 'gpt-4o', 'gpt-35-turbo', 'gpt-4-turbo'];
      let response: Response | null = null;
      
      for (const deploymentName of deploymentNames) {
        try {
          response = await fetch(`${this.endpoint}/openai/deployments/gpt-4.1/chat/completions`, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'api-key': this.apiKey
            },
            body: JSON.stringify({
              messages: [
                {
                  role: 'system',
                  content: systemPrompt
                },
                {
                  role: 'user',
                  content: request.message
                }
              ],
              max_tokens: 1000,
              temperature: 0.7
            })
          });

          if (response.ok) {
            const data = await response.json();
            const aiContent = data.choices[0]?.message?.content || 'I apologize, but I couldn\'t generate a response at this time.';
            return {
              content: aiContent
            };
          }
        } catch (error) {
          console.log(`Failed with deployment ${deploymentName}:`, error);
        }
      }

      // If all deployments failed, return fallback
      return {
        content: 'I\'m ready to help with your RFP! I can assist with content generation, technical specifications, project planning, and more. What would you like to work on?'
      };

    } catch (error) {
      console.error('Azure AI API error:', error);
      return {
        content: 'I\'m ready to help with your RFP! I can assist with content generation, technical specifications, project planning, and more. What would you like to work on?'
      };
    }
  }

  async testConnection(): Promise<boolean> {
    if (!this.endpoint || !this.apiKey) {
      return false;
    }

    try {
          response = await fetch(`${this.endpoint}/openai/deployments/gpt-4.1/chat/completions`, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'api-key': this.apiKey
            },
            body: JSON.stringify({
              messages: [
                {
                  role: 'user',
                  content: 'Hello, this is a test message.'
                }
              ],
              max_tokens: 10
            })
          });

          if (response.ok) {
            console.log(`Successfully connected using deployment: ${deploymentName}`);
            return true;
          }
        } catch (error) {
          lastError = error;
          console.log(`Failed with deployment ${deploymentName}:`, error);
        }
      }
      
      console.error('All deployment names failed. Last error:', lastError);
      return false;
    } catch (error) {
      console.error('Azure AI connection test failed:', error);
      return false;
    }
  }
}

export const chatbotService = new ChatbotService();