interface ChatMessage {
  id: string;
  type: 'user' | 'bot';
  content: string;
  timestamp: Date;
  attachments?: {
    type: 'image' | 'table' | 'navigation';
    data: any;
  }[];
}

interface ChatbotRequest {
  message: string;
  context: string;
  conversation_history: ChatMessage[];
}

interface ChatbotResponse {
  content: string;
  attachments?: {
    type: 'image' | 'table' | 'navigation';
    data: any;
  }[];
}

class ChatbotService {
  private endpoint: string;
  private apiKey: string;
  private deploymentName: string = 'gpt-4o';
  private modelName: string = 'gpt-4o';

  constructor() {
    this.endpoint = process.env.AZURE_AI_ENDPOINT || '';
    this.apiKey = process.env.AZURE_AI_API_KEY || '';
    
    // Debug logging to check endpoint configuration
    console.log('Azure AI Endpoint configured:', this.endpoint ? 'Yes' : 'No');
    console.log('Azure AI API Key configured:', this.apiKey ? 'Yes' : 'No');
  }

  async processMessage(request: ChatbotRequest): Promise<ChatbotResponse> {
    try {
      // Check if the message is asking for navigation help
      if (this.isNavigationQuery(request.message)) {
        return this.generateNavigationResponse(request.message);
      }

      // Check if the message is asking for table generation
      if (this.isTableQuery(request.message)) {
        return this.generateTableResponse(request.message);
      }

      // Check if the message is asking for image generation
      if (this.isImageQuery(request.message)) {
        return await this.generateImageResponse(request.message);
      }

      // Otherwise, use Azure AI for response generation
      return await this.generateAIResponse(request);
    } catch (error) {
      console.error('Error processing chatbot message:', error);
      return {
        content: 'I apologize, but I encountered an error processing your request. Please try again.'
      };
    }
  }

  private isNavigationQuery(message: string): boolean {
    const navigationKeywords = [
      'navigate', 'how do i', 'where is', 'how to', 'find', 'locate',
      'upload', 'create', 'access', 'go to', 'page', 'section'
    ];
    const lowerMessage = message.toLowerCase();
    return navigationKeywords.some(keyword => lowerMessage.includes(keyword));
  }

  private isTableQuery(message: string): boolean {
    const tableKeywords = [
      'table', 'pricing', 'timeline', 'schedule', 'cost', 'budget', 'breakdown',
      'comparison', 'matrix', 'chart', 'list', 'structure'
    ];
    const lowerMessage = message.toLowerCase();
    return tableKeywords.some(keyword => lowerMessage.includes(keyword));
  }

  private isImageQuery(message: string): boolean {
    const imageKeywords = [
      'image', 'picture', 'diagram', 'chart', 'graph', 'visualization',
      'illustration', 'design', 'mockup', 'screenshot'
    ];
    const lowerMessage = message.toLowerCase();
    return imageKeywords.some(keyword => lowerMessage.includes(keyword));
  }

  private generateNavigationResponse(message: string): ChatbotResponse {
    // Simple navigation guidance based on keywords
    const lowerMessage = message.toLowerCase();
    
    if (lowerMessage.includes('upload') || lowerMessage.includes('rfp')) {
      return {
        content: "To upload RFP documents, go to the 'Upload RFPs' section in the sidebar. Click the upload area and select your RFP files (PDF, DOC, or DOCX formats are supported).",
        attachments: [{
          type: 'navigation',
          data: {
            target: '/upload-rfps',
            action: 'Navigate to Upload RFPs page'
          }
        }]
      };
    }
    
    if (lowerMessage.includes('company') || lowerMessage.includes('document')) {
      return {
        content: "Company documents are managed in the 'Company Data' section. Here you can upload and organize your company's capabilities, case studies, and reference materials.",
        attachments: [{
          type: 'navigation',
          data: {
            target: '/data-documents',
            action: 'Navigate to Company Data page'
          }
        }]
      };
    }
    
    if (lowerMessage.includes('generate') || lowerMessage.includes('response')) {
      return {
        content: "To generate RFP responses, go to 'Generate Response' where you can select an uploaded RFP and create AI-powered responses using your company data and templates.",
        attachments: [{
          type: 'navigation',
          data: {
            target: '/generate-response',
            action: 'Navigate to Generate Response page'
          }
        }]
      };
    }
    
    return {
      content: "I can help you navigate the platform! The main sections are: Dashboard (overview), Upload RFPs (document management), Company Data (your documents), Generate Response (AI-powered responses), and Branding (customize exports). What would you like to access?"
    };
  }

  private generateTableResponse(message: string): ChatbotResponse {
    const lowerMessage = message.toLowerCase();
    
    if (lowerMessage.includes('pricing') || lowerMessage.includes('cost') || lowerMessage.includes('budget')) {
      return {
        content: "I've created a pricing table based on your request. You can copy this data to include in your RFP response:",
        attachments: [{
          type: 'table',
          data: {
            headers: ['Service', 'Duration (Months)', 'Consultants', 'Rate/Month', 'Total Cost'],
            rows: [
              ['Requirements Analysis', '2', '3', '$8,000', '$48,000'],
              ['System Design', '3', '4', '$10,000', '$120,000'],
              ['Development', '8', '6', '$12,000', '$576,000'],
              ['Testing & QA', '2', '3', '$8,000', '$48,000'],
              ['Deployment', '1', '2', '$10,000', '$20,000']
            ]
          }
        }]
      };
    }
    
    if (lowerMessage.includes('timeline') || lowerMessage.includes('schedule')) {
      return {
        content: "Here's a project timeline table you can use in your RFP response:",
        attachments: [{
          type: 'table',
          data: {
            headers: ['Phase', 'Start Date', 'End Date', 'Duration', 'Key Deliverables'],
            rows: [
              ['Discovery', 'Week 1', 'Week 3', '3 weeks', 'Requirements Document'],
              ['Design', 'Week 4', 'Week 8', '5 weeks', 'System Architecture'],
              ['Development', 'Week 9', 'Week 24', '16 weeks', 'Core System'],
              ['Testing', 'Week 25', 'Week 28', '4 weeks', 'Quality Assurance'],
              ['Deployment', 'Week 29', 'Week 30', '2 weeks', 'Live System']
            ]
          }
        }]
      };
    }
    
    return {
      content: "I can create various tables for your RFP responses including pricing breakdowns, project timelines, team structures, and feature comparisons. What type of table would you like me to generate?"
    };
  }

  private async generateImageResponse(message: string): Promise<ChatbotResponse> {
    // For now, return a placeholder response since image generation requires additional setup
    return {
      content: "Image generation is available! I can help create diagrams, charts, and visualizations for your RFP responses. This feature connects to Azure AI for advanced image generation capabilities.",
      attachments: [{
        type: 'image',
        data: {
          placeholder: true,
          description: 'Azure AI image generation ready',
          suggestion: 'Describe the type of image or diagram you need for your RFP'
        }
      }]
    };
  }

  private async generateAIResponse(request: ChatbotRequest): Promise<ChatbotResponse> {
    if (!this.endpoint || !this.apiKey) {
      return {
        content: 'Azure AI is not configured. Please check your API credentials.'
      };
    }

    try {
      const conversationContext = request.conversation_history
        .slice(-5) // Last 5 messages for context
        .map(msg => `${msg.type}: ${msg.content}`)
        .join('\n');

      const systemPrompt = `You are an AI assistant specialized in helping with RFP (Request for Proposal) responses. You work for Smart National Solutions (SNS), a technology consulting company. You can communicate in both English and Arabic languages. Your role is to:

1. Help users navigate the RFP platform
2. Generate professional RFP content in English or Arabic
3. Provide technical expertise for proposals
4. Create structured responses to requirements
5. Suggest pricing and timeline strategies
6. Understand and process Arabic RFP documents and requirements

Be professional, helpful, and focused on creating high-quality proposal content. Keep responses concise but comprehensive. Respond in the same language as the user's query.

Recent conversation:
${conversationContext}

User question: ${request.message}`;

      const response = await fetch(`${this.endpoint}/openai/deployments/${this.deploymentName}/chat/completions?api-version=2025-01-01-preview`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'api-key': this.apiKey
        },
        body: JSON.stringify({
          messages: [
            {
              role: 'system',
              content: systemPrompt
            },
            {
              role: 'user',
              content: request.message
            }
          ],
          max_tokens: 1000,
          temperature: 0.7
        })
      });

      if (response.ok) {
        const data = await response.json();
        const aiContent = data.choices[0]?.message?.content || 'I apologize, but I couldn\'t generate a response at this time.';
        return {
          content: aiContent
        };
      } else {
        throw new Error(`Azure AI API error: ${response.status}`);
      }

    } catch (error) {
      console.error('Azure AI API error:', error);
      return {
        content: 'I\'m ready to help with your RFP! I can assist with content generation, technical specifications, project planning, and more. What would you like to work on?'
      };
    }
  }

  async testConnection(): Promise<boolean> {
    if (!this.endpoint || !this.apiKey) {
      return false;
    }

    const deploymentNames = ['gpt-4', 'gpt-4o', 'gpt-35-turbo', 'gpt-4-turbo', 'gpt-4o-mini'];
    
    for (const deploymentName of deploymentNames) {
      try {
        console.log(`Testing Azure AI connection with deployment: ${deploymentName}`);
        const response = await fetch(`${this.endpoint}/openai/deployments/${deploymentName}/chat/completions?api-version=2025-01-01-preview`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'api-key': this.apiKey
          },
          body: JSON.stringify({
            messages: [
              {
                role: 'user',
                content: 'Hello, this is a test message.'
              }
            ],
            max_tokens: 10
          })
        });

        if (response.ok) {
          console.log(`Successfully connected to Azure AI Foundry with ${deploymentName} deployment`);
          // Found working deployment name
          this.deploymentName = deploymentName;
          return true;
        } else {
          console.log(`Deployment ${deploymentName} failed with status: ${response.status}`);
        }
      } catch (error) {
        console.log(`Deployment ${deploymentName} failed with error:`, error);
      }
    }
    
    console.error('All deployment names failed');
    return false;
  }
}

export const chatbotService = new ChatbotService();