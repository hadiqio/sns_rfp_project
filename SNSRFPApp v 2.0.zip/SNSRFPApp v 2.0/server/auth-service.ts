import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import crypto from 'crypto';
import nodemailer from 'nodemailer';
import { db } from './db';
import { users, verificationTokens, sessions } from '@shared/schema';
import { eq, and } from 'drizzle-orm';
import type { User, InsertUser } from '@shared/schema';

export class AuthService {
  private jwtSecret: string;
  private emailTransporter: nodemailer.Transporter;

  constructor() {
    this.jwtSecret = process.env.JWT_SECRET || 'your-super-secret-jwt-key';
    
    // Configure email transporter (using Gmail as example)
    this.emailTransporter = nodemailer.createTransport({
      service: 'gmail',
      auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASSWORD
      }
    });
  }

  // Generate verification token
  private generateToken(): string {
    return crypto.randomBytes(32).toString('hex');
  }

  // Hash password
  private async hashPassword(password: string): Promise<string> {
    return bcrypt.hash(password, 12);
  }

  // Verify password
  private async verifyPassword(password: string, hashedPassword: string): Promise<boolean> {
    return bcrypt.compare(password, hashedPassword);
  }

  // Generate JWT token
  private generateJWT(userId: number): string {
    return jwt.sign({ userId }, this.jwtSecret, { expiresIn: '7d' });
  }

  // Verify JWT token
  public verifyJWT(token: string): { userId: number } | null {
    try {
      return jwt.verify(token, this.jwtSecret) as { userId: number };
    } catch {
      return null;
    }
  }

  // Register new user
  async register(userData: InsertUser): Promise<{ success: boolean; message: string; userId?: number }> {
    try {
      // Check if user already exists
      const existingUser = await db.select().from(users).where(eq(users.email, userData.email)).limit(1);
      
      if (existingUser.length > 0) {
        return { success: false, message: 'User with this email already exists' };
      }

      // Create user (without password initially)
      const [newUser] = await db.insert(users).values({
        email: userData.email,
        firstName: userData.firstName,
        lastName: userData.lastName,
        isActive: false,
        emailVerified: false
      }).returning();

      // Generate verification token
      const token = this.generateToken();
      const expiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000); // 24 hours

      await db.insert(verificationTokens).values({
        userId: newUser.id,
        token,
        type: 'email_verification',
        expiresAt
      });

      // Send verification email
      await this.sendVerificationEmail(userData.email, token, userData.firstName || 'User');

      return { 
        success: true, 
        message: 'Registration successful! Please check your email for verification link.',
        userId: newUser.id 
      };
    } catch (error) {
      console.error('Registration error:', error);
      return { success: false, message: 'Registration failed. Please try again.' };
    }
  }

  // Verify email with token
  async verifyEmail(token: string): Promise<{ success: boolean; message: string; userId?: number }> {
    try {
      // Find valid verification token
      const [verificationToken] = await db
        .select()
        .from(verificationTokens)
        .where(
          and(
            eq(verificationTokens.token, token),
            eq(verificationTokens.type, 'email_verification')
          )
        )
        .limit(1);

      if (!verificationToken || verificationToken.usedAt) {
        return { success: false, message: 'Invalid or expired verification token' };
      }

      // Check if token is expired
      if (new Date() > verificationToken.expiresAt) {
        return { success: false, message: 'Verification token has expired' };
      }

      // Update user as verified
      await db
        .update(users)
        .set({ emailVerified: true, updatedAt: new Date() })
        .where(eq(users.id, verificationToken.userId));

      // Mark token as used
      await db
        .update(verificationTokens)
        .set({ usedAt: new Date() })
        .where(eq(verificationTokens.id, verificationToken.id));

      return { 
        success: true, 
        message: 'Email verified successfully! You can now set your password.',
        userId: verificationToken.userId 
      };
    } catch (error) {
      console.error('Email verification error:', error);
      return { success: false, message: 'Email verification failed. Please try again.' };
    }
  }

  // Set password for verified user
  async setPassword(userId: number, password: string): Promise<{ success: boolean; message: string }> {
    try {
      // Check if user exists and is verified
      const [user] = await db.select().from(users).where(eq(users.id, userId)).limit(1);
      
      if (!user) {
        return { success: false, message: 'User not found' };
      }

      if (!user.emailVerified) {
        return { success: false, message: 'Email must be verified before setting password' };
      }

      // Hash password and update user
      const hashedPassword = await this.hashPassword(password);
      
      await db
        .update(users)
        .set({ 
          password: hashedPassword,
          isActive: true,
          updatedAt: new Date()
        })
        .where(eq(users.id, userId));

      return { success: true, message: 'Password set successfully! You can now login.' };
    } catch (error) {
      console.error('Set password error:', error);
      return { success: false, message: 'Failed to set password. Please try again.' };
    }
  }

  // Login user
  async login(email: string, password: string): Promise<{ success: boolean; message: string; token?: string; user?: User }> {
    try {
      // Find user
      const [user] = await db.select().from(users).where(eq(users.email, email)).limit(1);
      
      if (!user) {
        return { success: false, message: 'Invalid email or password' };
      }

      if (!user.isActive || !user.emailVerified || !user.password) {
        return { success: false, message: 'Account not activated. Please verify your email and set password.' };
      }

      // Verify password
      const isValidPassword = await this.verifyPassword(password, user.password);
      
      if (!isValidPassword) {
        return { success: false, message: 'Invalid email or password' };
      }

      // Generate JWT token
      const token = this.generateJWT(user.id);

      // Update last login
      await db
        .update(users)
        .set({ lastLoginAt: new Date() })
        .where(eq(users.id, user.id));

      // Create session
      const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000); // 7 days
      await db.insert(sessions).values({
        userId: user.id,
        token,
        expiresAt
      });

      return { 
        success: true, 
        message: 'Login successful!',
        token,
        user: { ...user, password: null } // Remove password from response
      };
    } catch (error) {
      console.error('Login error:', error);
      return { success: false, message: 'Login failed. Please try again.' };
    }
  }

  // Send verification email
  private async sendVerificationEmail(email: string, token: string, firstName: string): Promise<void> {
    const verificationUrl = `${process.env.APP_URL || 'http://localhost:5000'}/verify-email?token=${token}`;
    
    const mailOptions = {
      from: process.env.EMAIL_FROM || process.env.EMAIL_USER,
      to: email,
      subject: 'SNS RFP Generator - Verify Your Email',
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
          <div style="text-align: center; margin-bottom: 30px;">
            <h1 style="color: #0EA5E9; margin: 0;">Smart National Solutions</h1>
            <p style="color: #666; margin: 5px 0;">RFP Generator Platform</p>
          </div>
          
          <h2 style="color: #333;">Welcome ${firstName}!</h2>
          <p>Thank you for registering with SNS RFP Generator. To complete your account setup, please verify your email address by clicking the button below:</p>
          
          <div style="text-align: center; margin: 30px 0;">
            <a href="${verificationUrl}" style="background-color: #0EA5E9; color: white; padding: 12px 30px; text-decoration: none; border-radius: 5px; display: inline-block;">
              Verify Email Address
            </a>
          </div>
          
          <p style="color: #666; font-size: 14px;">
            If the button doesn't work, copy and paste this link into your browser:<br>
            <a href="${verificationUrl}">${verificationUrl}</a>
          </p>
          
          <p style="color: #666; font-size: 14px;">
            This verification link will expire in 24 hours for security reasons.
          </p>
          
          <hr style="border: none; height: 1px; background-color: #eee; margin: 30px 0;">
          <p style="color: #999; font-size: 12px; text-align: center;">
            If you didn't create an account with SNS RFP Generator, please ignore this email.
          </p>
        </div>
      `
    };

    await this.emailTransporter.sendMail(mailOptions);
  }

  // Get user by ID
  async getUserById(userId: number): Promise<User | null> {
    try {
      const [user] = await db.select().from(users).where(eq(users.id, userId)).limit(1);
      return user ? { ...user, password: null } : null;
    } catch (error) {
      console.error('Get user error:', error);
      return null;
    }
  }

  // Verify session token
  async verifySession(token: string): Promise<User | null> {
    try {
      // Verify JWT
      const decoded = this.verifyJWT(token);
      if (!decoded) return null;

      // Check session in database
      const [session] = await db
        .select()
        .from(sessions)
        .where(eq(sessions.token, token))
        .limit(1);

      if (!session || new Date() > session.expiresAt) {
        return null;
      }

      // Get user
      return this.getUserById(session.userId);
    } catch (error) {
      console.error('Session verification error:', error);
      return null;
    }
  }

  // Logout (invalidate session)
  async logout(token: string): Promise<{ success: boolean; message: string }> {
    try {
      await db.delete(sessions).where(eq(sessions.token, token));
      return { success: true, message: 'Logged out successfully' };
    } catch (error) {
      console.error('Logout error:', error);
      return { success: false, message: 'Logout failed' };
    }
  }
}

export const authService = new AuthService();