import { Pool } from 'pg';
import { drizzle } from 'drizzle-orm/node-postgres';
import * as schema from "@shared/schema";

// Azure PostgreSQL configuration
const pool = new Pool({
  host: "snsrfpdb.postgres.database.azure.com",
  user: "user",
  password: process.env.AZURE_DB_PASSWORD || "",
  database: "postgres",
  port: 5432,
  ssl: {
    rejectUnauthorized: false
  }
});

// Test the connection
pool.on('error', (err) => {
  console.error('PostgreSQL pool error:', err);
});

// Test connection on startup
pool.connect((err, client, release) => {
  if (err) {
    console.error('Error connecting to PostgreSQL:', err);
  } else {
    console.log('Successfully connected to Azure PostgreSQL');
    release();
  }
});

export const db = drizzle(pool, { schema });
export { pool };