import React, { createContext, useContext, useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useLocation } from 'wouter';
import type { RfpDocument, CompanyDocument, RfpResponse, BrandingSettings } from '@shared/schema';

interface WorkflowStep {
  id: string;
  title: string;
  description: string;
  path: string;
  completed: boolean;
  current: boolean;
}

interface WorkflowContextType {
  steps: WorkflowStep[];
  currentStepIndex: number;
  selectedRfpId: number | null;
  setSelectedRfpId: (id: number | null) => void;
  navigateToStep: (path: string) => void;
  navigateNext: () => void;
  navigatePrevious: () => void;
  canProceedToNext: boolean;
  updateStepCompletion: () => void;
}

const WorkflowContext = createContext<WorkflowContextType | undefined>(undefined);

export function useWorkflow() {
  const context = useContext(WorkflowContext);
  if (!context) {
    throw new Error('useWorkflow must be used within a WorkflowProvider');
  }
  return context;
}

export function WorkflowProvider({ children }: { children: React.ReactNode }) {
  const [location, setLocation] = useLocation();
  const [selectedRfpId, setSelectedRfpId] = useState<number | null>(null);
  const [brandPresentationStatus, setBrandPresentationStatus] = useState<boolean>(false);

  // Check for brand presentation on mount and whenever localStorage might change
  useEffect(() => {
    const checkBrandPresentation = () => {
      const savedPresentation = localStorage.getItem('sns_brand_presentation');
      setBrandPresentationStatus(!!savedPresentation);
    };
    
    checkBrandPresentation();
    
    // Listen for storage events to update when brand presentation is uploaded
    window.addEventListener('storage', checkBrandPresentation);
    // Also listen for a custom event we'll trigger when uploading
    window.addEventListener('brandPresentationUpdated', checkBrandPresentation);
    
    return () => {
      window.removeEventListener('storage', checkBrandPresentation);
      window.removeEventListener('brandPresentationUpdated', checkBrandPresentation);
    };
  }, []);

  // Fetch data to determine completion status
  const { data: rfpDocuments } = useQuery<RfpDocument[]>({
    queryKey: ["/api/rfp-documents"],
  });

  const { data: companyDocuments } = useQuery<CompanyDocument[]>({
    queryKey: ["/api/company-documents"],
  });

  const { data: responses } = useQuery<RfpResponse[]>({
    queryKey: ["/api/rfp-responses"],
  });

  const { data: branding } = useQuery<BrandingSettings>({
    queryKey: ["/api/branding"],
  });

  const stepDefinitions = [
    {
      id: 'upload',
      title: 'Upload RFP',
      description: 'Upload and process RFP document',
      path: '/upload-rfps',
    },
    {
      id: 'data',
      title: 'Company Data',
      description: 'Manage company documents',
      path: '/data-documents',
    },
    {
      id: 'generate',
      title: 'Generate Response',
      description: 'AI-powered response creation',
      path: '/generate-response',
    },
    {
      id: 'branding',
      title: 'SNS Branding',
      description: 'Configure branding settings',
      path: '/branding',
    },
    {
      id: 'export',
      title: 'Preview & Export',
      description: 'Review and export final document',
      path: '/preview-export',
    },
  ];

  const currentStepIndex = stepDefinitions.findIndex(step => step.path === location);

  const steps: WorkflowStep[] = stepDefinitions.map((step, index) => {
    let completed = false;
    
    // Determine completion status based on data availability
    switch (step.id) {
      case 'upload':
        completed = (rfpDocuments && rfpDocuments.length > 0) || false;
        break;
      case 'data':
        completed = (companyDocuments && companyDocuments.length > 0) || false;
        break;
      case 'generate':
        completed = (responses && responses.length > 0) || false;
        break;
      case 'branding':
        // Check both branding settings and uploaded brand presentation
        const hasBrandingSettings = !!branding;
        completed = hasBrandingSettings || brandPresentationStatus;
        break;
      case 'export':
        completed = false; // Always requires manual review
        break;
    }

    return {
      ...step,
      completed,
      current: index === currentStepIndex,
    };
  });

  const navigateToStep = (path: string) => {
    setLocation(path);
  };

  const navigateNext = () => {
    if (currentStepIndex < steps.length - 1) {
      const nextStep = steps[currentStepIndex + 1];
      setLocation(nextStep.path);
    }
  };

  const navigatePrevious = () => {
    if (currentStepIndex > 0) {
      const previousStep = steps[currentStepIndex - 1];
      setLocation(previousStep.path);
    }
  };

  // Determine if user can proceed to next step
  const canProceedToNext = () => {
    const currentStep = steps[currentStepIndex];
    if (!currentStep) return false;

    switch (currentStep.id) {
      case 'upload':
        return !!(rfpDocuments && rfpDocuments.length > 0);
      case 'data':
        return !!(companyDocuments && companyDocuments.length > 0);
      case 'generate':
        return !!(responses && responses.length > 0);
      case 'branding':
        return true; // Optional step, can always proceed
      case 'export':
        return false; // Final step
      default:
        return false;
    }
  };

  const updateStepCompletion = () => {
    // This function can be called to refresh completion status
    // The completion status is automatically updated via queries
  };

  return (
    <WorkflowContext.Provider
      value={{
        steps,
        currentStepIndex,
        selectedRfpId,
        setSelectedRfpId,
        navigateToStep,
        navigateNext,
        navigatePrevious,
        canProceedToNext: canProceedToNext(),
        updateStepCompletion,
      }}
    >
      {children}
    </WorkflowContext.Provider>
  );
}