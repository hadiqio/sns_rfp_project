import { createContext, useContext, ReactNode } from 'react';

interface ChatbotContextType {
  isChatbotOpen: boolean;
  onChatbotToggle: () => void;
}

const ChatbotContext = createContext<ChatbotContextType | undefined>(undefined);

export function ChatbotProvider({ 
  children, 
  isChatbotOpen, 
  onChatbotToggle 
}: { 
  children: ReactNode;
  isChatbotOpen: boolean;
  onChatbotToggle: () => void;
}) {
  return (
    <ChatbotContext.Provider value={{ isChatbotOpen, onChatbotToggle }}>
      {children}
    </ChatbotContext.Provider>
  );
}

export function useChatbot() {
  const context = useContext(ChatbotContext);
  if (context === undefined) {
    throw new Error('useChatbot must be used within a ChatbotProvider');
  }
  return context;
}