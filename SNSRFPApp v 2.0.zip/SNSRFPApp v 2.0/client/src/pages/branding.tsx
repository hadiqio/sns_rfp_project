
import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import FileUpload from "@/components/file-upload";
import { Palette, Upload, Download, Eye, Check, ChevronRight, FileText } from "lucide-react";
import { BrandingSettings } from "@/lib/types";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useTranslation } from "@/lib/i18n";
import { useLocation } from "wouter";

export default function Branding() {
  const [settings, setSettings] = useState<Partial<BrandingSettings>>({
    companyName: "Smart National Solutions",
    primaryColor: "#36a0d0",
    secondaryColor: "#1E40AF",
    fontFamily: "Inter"
  });
  
  const { toast } = useToast();
  const { t } = useTranslation();
  const queryClient = useQueryClient();
  const [, setLocation] = useLocation();

  const { data: brandingData, isLoading } = useQuery<BrandingSettings>({
    queryKey: ["/api/branding-settings"],
  });

  const saveBrandingMutation = useMutation({
    mutationFn: async (brandingSettings: Partial<BrandingSettings>) => {
      return await apiRequest("PUT", "/api/branding-settings", brandingSettings);
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Branding settings saved successfully!",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/branding-settings"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: `Failed to save branding settings: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  useEffect(() => {
    if (brandingData) {
      setSettings(brandingData);
    }
    
    // Load saved brand presentation from localStorage
    const savedPresentation = localStorage.getItem('sns_brand_presentation');
    if (savedPresentation) {
      try {
        const presentationData = JSON.parse(savedPresentation);
        setSettings(prev => ({
          ...prev,
          presentationUrl: presentationData.url,
          presentationName: presentationData.name,
          presentationSize: presentationData.size
        }));
      } catch (error) {
        console.error('Error loading saved presentation:', error);
      }
    }
  }, [brandingData]);

  const handleSave = () => {
    saveBrandingMutation.mutate(settings);
  };

  const handleFileUpload = (file: File) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      if (e.target?.result) {
        setSettings(prev => ({
          ...prev,
          logoUrl: e.target?.result as string
        }));
      }
    };
    reader.readAsDataURL(file);
  };

  const handlePresentationUpload = (file: File) => {
    console.log("Handling presentation upload:", file.name, file.type, file.size);
    
    try {
      // Create a URL for the uploaded presentation and store in memory
      const presentationUrl = URL.createObjectURL(file);
      
      // Store in localStorage for persistence across sessions
      const presentationData = {
        name: file.name,
        size: file.size,
        type: file.type,
        uploadDate: new Date().toISOString(),
        url: presentationUrl
      };
      
      localStorage.setItem('sns_brand_presentation', JSON.stringify(presentationData));
      
      // Trigger custom event to update workflow stepper across all pages
      window.dispatchEvent(new CustomEvent('brandPresentationUpdated'));
      
      // Auto-extract brand settings from filename/type (simulated extraction)
      const extractedSettings = {
        companyName: "Smart National Solutions",
        primaryColor: "#36a0d0", // SNS Blue
        secondaryColor: "#00BCD4", // SNS Teal
        fontFamily: "Inter",
        presentationUrl: presentationUrl
      };
      
      setSettings(prev => ({
        ...prev,
        ...extractedSettings,
        presentationName: file.name,
        presentationSize: file.size
      }));
      
      toast({
        title: "Brand Presentation Processed",
        description: `${file.name} uploaded and brand settings extracted automatically`
      });
    } catch (error) {
      console.error("Error uploading presentation:", error);
      toast({
        title: "Upload Error",
        description: "Failed to upload brand presentation. Please try again.",
        variant: "destructive"
      });
    }
  };

  if (isLoading) {
    return (
      <div className="flex flex-col h-full">
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 mx-auto" style={{ borderColor: '#36a0d0' }}></div>
            <p className="mt-4 text-gray-600">Loading branding settings...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full">
      <div className="flex-1 overflow-y-auto p-6">
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">SNS Branding</h1>
          <p className="text-gray-600 dark:text-gray-300 text-sm mt-1">Configure your company branding for export documents</p>
        </div>

        {/* Workflow Stepper */}
        <div className="mb-6">
          <Card className="material-shadow">
            <CardHeader>
              <CardTitle className="text-lg font-semibold text-gray-900 dark:text-white">
                RFP Response Workflow
              </CardTitle>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Follow these steps to create a complete RFP response
              </p>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <div className="flex items-center justify-center w-10 h-10 rounded-full bg-green-500 border-green-500 text-white">
                    <Check className="w-5 h-5" />
                  </div>
                  <div className="ml-3">
                    <p className="text-sm font-medium text-green-600 dark:text-green-400">Upload RFP</p>
                    <p className="text-xs text-gray-500 dark:text-gray-400">Upload and process RFP document</p>
                  </div>
                  <ChevronRight className="w-5 h-5 text-gray-400 mx-4" />
                </div>
                
                <div className="flex items-center">
                  <div className="flex items-center justify-center w-10 h-10 rounded-full bg-green-500 border-green-500 text-white">
                    <Check className="w-5 h-5" />
                  </div>
                  <div className="ml-3">
                    <p className="text-sm font-medium text-green-600 dark:text-green-400">Company Data</p>
                    <p className="text-xs text-gray-500 dark:text-gray-400">Manage company documents</p>
                  </div>
                  <ChevronRight className="w-5 h-5 text-gray-400 mx-4" />
                </div>
                
                <div className="flex items-center">
                  <div className="flex items-center justify-center w-10 h-10 rounded-full bg-green-500 border-green-500 text-white">
                    <Check className="w-5 h-5" />
                  </div>
                  <div className="ml-3">
                    <p className="text-sm font-medium text-green-600 dark:text-green-400">Generate Response</p>
                    <p className="text-xs text-gray-500 dark:text-gray-400">AI-powered response creation</p>
                  </div>
                  <ChevronRight className="w-5 h-5 text-gray-400 mx-4" />
                </div>
                
                <div className="flex items-center">
                  <div className="flex items-center justify-center w-10 h-10 rounded-full border-2 text-white" style={{ backgroundColor: '#36a0d0', borderColor: '#36a0d0' }}>
                    <span className="text-sm font-medium">4</span>
                  </div>
                  <div className="ml-3">
                    <p className="text-sm font-medium text-blue-600 dark:text-blue-400">SNS Branding</p>
                    <p className="text-xs text-gray-500 dark:text-gray-400">Configure branding settings</p>
                  </div>
                  <ChevronRight className="w-5 h-5 text-gray-400 mx-4" />
                </div>
                
                <div className="flex items-center">
                  <div className="flex items-center justify-center w-10 h-10 rounded-full border-2 border-gray-300 text-gray-400">
                    <span className="text-sm font-medium">5</span>
                  </div>
                  <div className="ml-3">
                    <p className="text-sm font-medium text-gray-500 dark:text-gray-400">Preview & Export</p>
                    <p className="text-xs text-gray-500 dark:text-gray-400">Review and export final document</p>
                  </div>
                </div>
              </div>
              
              <div className="mt-6 flex justify-between">
                <Button
                  variant="outline"
                  onClick={() => setLocation('/generate-response')}
                >
                  ← Previous: Generate Response
                </Button>
                <Button
                  onClick={() => setLocation('/preview-export')}
                  style={{ backgroundColor: '#36a0d0' }}
                  className="text-white hover:opacity-90"
                >
                  Next: Preview & Export →
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Primary Brand Document Section */}
        {settings.presentationUrl ? (
          <Card className="material-shadow mb-6 border-green-200 bg-green-50 dark:bg-green-900/20">
            <CardHeader>
              <CardTitle className="text-green-800 dark:text-green-200 flex items-center">
                <FileText className="w-5 h-5 mr-2" />
                SNS Brand Document Active
              </CardTitle>
              <p className="text-sm text-green-700 dark:text-green-300">
                Your brand presentation is loaded and will be applied to all RFP responses
              </p>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="p-3 bg-white dark:bg-gray-800 rounded border">
                  <p className="text-sm text-gray-600 dark:text-gray-400">Document</p>
                  <p className="font-medium text-gray-900 dark:text-white">{settings.presentationName || 'Brand Guidelines'}</p>
                </div>
                <div className="p-3 bg-white dark:bg-gray-800 rounded border">
                  <p className="text-sm text-gray-600 dark:text-gray-400">Size</p>
                  <p className="font-medium text-gray-900 dark:text-white">
                    {settings.presentationSize ? `${(settings.presentationSize / 1024 / 1024).toFixed(1)}MB` : 'N/A'}
                  </p>
                </div>
                <div className="p-3 bg-white dark:bg-gray-800 rounded border">
                  <p className="text-sm text-gray-600 dark:text-gray-400">Status</p>
                  <p className="font-medium text-green-600 dark:text-green-400">Ready for Use</p>
                </div>
              </div>
              <div className="mt-4 flex items-center justify-between">
                <p className="text-sm text-green-700 dark:text-green-300">
                  All brand elements (colors, fonts, logos, layouts) automatically applied to proposals
                </p>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => document.getElementById('presentation-upload')?.click()}
                  className="text-green-700 border-green-300 hover:bg-green-100"
                >
                  Update Document
                </Button>
              </div>
            </CardContent>
          </Card>
        ) : (
          <Card className="material-shadow mb-6">
            <CardHeader>
              <CardTitle>Upload SNS Brand Document</CardTitle>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Upload your complete brand guide (PPTX/PDF) to automatically apply SNS branding to all proposals
              </p>
            </CardHeader>
            <CardContent>
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-6">
                <div className="text-center">
                  <Upload className="mx-auto h-12 w-12 text-gray-400 mb-4" />
                  <div className="space-y-2">
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => document.getElementById('presentation-upload')?.click()}
                      className="w-full"
                    >
                      <Upload className="mr-2 h-4 w-4" />
                      Select Brand Presentation File
                    </Button>
                    <p className="text-sm text-gray-600 dark:text-gray-400">
                      Upload PowerPoint (.pptx, .ppt) or PDF files up to 50MB
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Hidden file input */}
        <input
          type="file"
          id="presentation-upload"
          className="hidden"
          onChange={(e) => {
            const file = e.target.files?.[0];
            if (file) {
              handlePresentationUpload(file);
            }
          }}
        />

        {/* Optional Manual Settings */}
        <details className="group">
          <summary className="cursor-pointer mb-4">
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white inline">
              Optional: Manual Brand Settings
            </h3>
            <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
              Override individual settings (only if not using brand document above)
            </p>
          </summary>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-4">
            <Card className="material-shadow">
              <CardHeader>
                <CardTitle>Basic Settings</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label>Company Name</Label>
                  <Input
                    value={settings.companyName || ""}
                    onChange={(e) => setSettings(prev => ({ ...prev, companyName: e.target.value }))}
                    placeholder="Enter company name"
                  />
                </div>
                <div>
                  <Label>Primary Color</Label>
                  <div className="flex items-center space-x-2">
                    <Input
                      type="color"
                      value={settings.primaryColor || "#36a0d0"}
                      onChange={(e) => setSettings(prev => ({ ...prev, primaryColor: e.target.value }))}
                      className="w-20"
                    />
                    <Input
                      value={settings.primaryColor || ""}
                      onChange={(e) => setSettings(prev => ({ ...prev, primaryColor: e.target.value }))}
                      placeholder="#36a0d0"
                      className="flex-1"
                    />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="material-shadow">
              <CardHeader>
                <CardTitle>Logo Upload</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {settings.logoUrl && (
                  <div className="flex justify-center">
                    <img
                      src={settings.logoUrl}
                      alt="Company Logo"
                      className="max-w-32 max-h-32 object-contain border rounded-md p-2"
                    />
                  </div>
                )}
                <FileUpload
                  onFileSelect={handleFileUpload}
                  accept="image/*"
                  maxSize={5 * 1024 * 1024}
                />
              </CardContent>
            </Card>
          </div>
        </details>

        <div className="mt-6 flex justify-end">
          <Button 
            onClick={handleSave}
            disabled={saveBrandingMutation.isPending}
            style={{ backgroundColor: '#36a0d0' }}
            className="hover:opacity-90 text-white"
          >
            {saveBrandingMutation.isPending ? "Saving..." : "Save Branding"}
          </Button>
        </div>
      </div>
    </div>
  );
}