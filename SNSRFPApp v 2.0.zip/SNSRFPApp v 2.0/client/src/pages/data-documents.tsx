import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";

import FileUpload from "@/components/file-upload";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Trash2, FileText, FolderOpen, ChevronRight, Check } from "lucide-react";
import { CompanyDocument } from "@/lib/types";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";

const categories = [
  { value: "company-info", label: "Company Information" },
  { value: "capabilities", label: "Capabilities & Services" },
  { value: "case-studies", label: "Case Studies" },
  { value: "technical-specs", label: "Technical Specifications" },
  { value: "certifications", label: "Certifications" },
  { value: "templates", label: "Response Templates" },
  { value: "other", label: "Other" },
];

export default function DataDocuments() {
  const [uploadForm, setUploadForm] = useState({
    title: "",
    category: "",
    file: null as File | null,
  });
  const [selectedCategory, setSelectedCategory] = useState("all");
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [, setLocation] = useLocation();

  const { data: documents, isLoading } = useQuery<CompanyDocument[]>({
    queryKey: ["/api/company-documents"],
  });

  const uploadMutation = useMutation({
    mutationFn: async (data: { title: string; category: string; file: File }) => {
      const formData = new FormData();
      formData.append("title", data.title);
      formData.append("category", data.category);
      formData.append("file", data.file);
      
      const response = await fetch("/api/company-documents", {
        method: "POST",
        body: formData,
      });
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      return response.json();
    },
    onSuccess: (data) => {
      console.log('Upload successful, response:', data);
      toast({
        title: "Success",
        description: "Document uploaded successfully",
      });
      // Force refresh the company documents query
      queryClient.invalidateQueries({ queryKey: ["/api/company-documents"] });
      queryClient.refetchQueries({ queryKey: ["/api/company-documents"] });
      setUploadForm({ title: "", category: "", file: null });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to upload document",
        variant: "destructive",
      });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/company-documents/${id}`);
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Document deleted successfully",
      });
      // Invalidate all company documents queries regardless of category filter
      queryClient.invalidateQueries({ 
        queryKey: ["/api/company-documents"],
        exact: false 
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to delete document",
        variant: "destructive",
      });
    },
  });

  const handleFileSelect = (file: File) => {
    setUploadForm(prev => ({ ...prev, file }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Debug logging to identify missing fields
    console.log("Form submission - uploadForm:", {
      title: uploadForm.title,
      category: uploadForm.category,
      file: uploadForm.file ? { name: uploadForm.file.name, size: uploadForm.file.size } : null
    });
    
    const missingFields = [];
    if (!uploadForm.title) missingFields.push("title");
    if (!uploadForm.category) missingFields.push("category");
    if (!uploadForm.file) missingFields.push("file");
    
    console.log("Missing fields:", missingFields);
    
    if (missingFields.length > 0) {
      const fieldNames = missingFields.map(field => {
        switch(field) {
          case 'title': return 'Document Title';
          case 'category': return 'Category';
          case 'file': return 'File';
          default: return field;
        }
      }).join(', ');
      
      toast({
        title: "Error",
        description: `Please fill in: ${fieldNames}`,
        variant: "destructive",
      });
      return;
    }

    uploadMutation.mutate({
      title: uploadForm.title,
      category: uploadForm.category,
      file: uploadForm.file as File
    });
  };

  const getCategoryLabel = (category: string) => {
    return categories.find(c => c.value === category)?.label || category;
  };

  const getCategoryColor = (category: string) => {
    const colors: Record<string, string> = {
      "company-info": "bg-blue-100 text-blue-800",
      "capabilities": "bg-green-100 text-green-800",
      "case-studies": "bg-purple-100 text-purple-800",
      "technical-specs": "bg-orange-100 text-orange-800",
      "certifications": "bg-yellow-100 text-yellow-800",
      "templates": "bg-pink-100 text-pink-800",
      "other": "bg-gray-100 text-gray-800",
    };
    return colors[category] || colors.other;
  };

  const filteredDocuments = (documents || []) as CompanyDocument[];

  return (
    <div className="flex flex-col h-full">
      <div className="flex-1 overflow-y-auto p-6">
        {/* Page Title */}
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Company Data</h1>
          <p className="text-gray-600 dark:text-gray-300 text-sm mt-1">Upload your company documents, capabilities, case studies, and previous work samples. These will be used to create compelling RFP responses.</p>
        </div>

        {/* Workflow Stepper */}
        <div className="mb-6">
          <Card className="material-shadow">
            <CardHeader>
              <CardTitle className="text-lg font-semibold text-gray-900 dark:text-white">
                RFP Response Workflow
              </CardTitle>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Follow these steps to create a complete RFP response
              </p>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <div className="flex items-center justify-center w-10 h-10 rounded-full bg-green-500 border-green-500 text-white">
                    <Check className="w-5 h-5" />
                  </div>
                  <div className="ml-3">
                    <p className="text-sm font-medium text-green-600 dark:text-green-400">Upload RFP</p>
                    <p className="text-xs text-gray-500 dark:text-gray-400">Upload and process RFP document</p>
                  </div>
                  <ChevronRight className="w-5 h-5 text-gray-400 mx-4" />
                </div>
                
                <div className="flex items-center">
                  <div className="flex items-center justify-center w-10 h-10 rounded-full border-2 text-white" style={{ backgroundColor: '#36a0d0', borderColor: '#36a0d0' }}>
                    <span className="text-sm font-medium">2</span>
                  </div>
                  <div className="ml-3">
                    <p className="text-sm font-medium text-blue-600 dark:text-blue-400">Company Data</p>
                    <p className="text-xs text-gray-500 dark:text-gray-400">Manage company documents</p>
                  </div>
                  <ChevronRight className="w-5 h-5 text-gray-400 mx-4" />
                </div>
                
                <div className="flex items-center">
                  <div className="flex items-center justify-center w-10 h-10 rounded-full border-2 border-gray-300 text-gray-400">
                    <span className="text-sm font-medium">3</span>
                  </div>
                  <div className="ml-3">
                    <p className="text-sm font-medium text-gray-500 dark:text-gray-400">Generate Response</p>
                    <p className="text-xs text-gray-500 dark:text-gray-400">AI-powered response creation</p>
                  </div>
                  <ChevronRight className="w-5 h-5 text-gray-400 mx-4" />
                </div>
                
                <div className="flex items-center">
                  <div className="flex items-center justify-center w-10 h-10 rounded-full border-2 border-gray-300 text-gray-400">
                    <span className="text-sm font-medium">4</span>
                  </div>
                  <div className="ml-3">
                    <p className="text-sm font-medium text-gray-500 dark:text-gray-400">SNS Branding</p>
                    <p className="text-xs text-gray-500 dark:text-gray-400">Configure branding settings</p>
                  </div>
                  <ChevronRight className="w-5 h-5 text-gray-400 mx-4" />
                </div>
                
                <div className="flex items-center">
                  <div className="flex items-center justify-center w-10 h-10 rounded-full border-2 border-gray-300 text-gray-400">
                    <span className="text-sm font-medium">5</span>
                  </div>
                  <div className="ml-3">
                    <p className="text-sm font-medium text-gray-500 dark:text-gray-400">Preview & Export</p>
                    <p className="text-xs text-gray-500 dark:text-gray-400">Review and export final document</p>
                  </div>
                </div>
              </div>
              
              <div className="mt-6 flex justify-between">
                <Button
                  variant="outline"
                  onClick={() => setLocation('/upload-rfps')}
                >
                  ← Previous: Upload RFP
                </Button>
                <Button
                  onClick={() => setLocation('/generate-response')}
                  style={{ backgroundColor: '#36a0d0' }}
                  className="text-white hover:opacity-90"
                  disabled={!documents || documents.length === 0}
                >
                  Next: Generate Response →
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Upload Form */}
          <div className="lg:col-span-1">
            <Card className="material-shadow">
              <CardHeader>
                <CardTitle>Upload Document</CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div>
                    <Label htmlFor="title">Document Title</Label>
                    <Input
                      id="title"
                      value={uploadForm.title}
                      onChange={(e) => setUploadForm(prev => ({ ...prev, title: e.target.value }))}
                      placeholder="Enter document title"
                      required
                    />
                  </div>

                  <div>
                    <Label htmlFor="category">Category</Label>
                    <Select 
                      value={uploadForm.category} 
                      onValueChange={(value) => setUploadForm(prev => ({ ...prev, category: value }))}
                      required
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select category" />
                      </SelectTrigger>
                      <SelectContent>
                        {categories.map((category) => (
                          <SelectItem key={category.value} value={category.value}>
                            {category.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label>Document File</Label>
                    <FileUpload onFileSelect={handleFileSelect} />
                  </div>

                  <Button
                    type="submit"
                    className="w-full text-white hover:opacity-90"
                    style={{ backgroundColor: '#36a0d0' }}
                    disabled={uploadMutation.isPending}
                  >
                    {uploadMutation.isPending ? "Uploading..." : "Upload Document"}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>

          {/* Documents List */}
          <div className="lg:col-span-3">
            <Card className="material-shadow">
              <CardHeader>
                <CardTitle>Company Documents</CardTitle>
              </CardHeader>
              <CardContent>
                <DocumentList
                  documents={filteredDocuments}
                  isLoading={isLoading}
                  onDelete={(id) => deleteMutation.mutate(id)}
                  deleteLoading={deleteMutation.isPending}
                />
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}

interface DocumentListProps {
  documents: CompanyDocument[];
  isLoading: boolean;
  onDelete: (id: number) => void;
  deleteLoading: boolean;
}

function DocumentList({ documents, isLoading, onDelete, deleteLoading }: DocumentListProps) {
  const getCategoryColor = (category: string) => {
    const colors: Record<string, string> = {
      "company-info": "bg-blue-100 text-blue-800",
      "capabilities": "bg-green-100 text-green-800",
      "case-studies": "bg-purple-100 text-purple-800",
      "technical-specs": "bg-orange-100 text-orange-800",
      "certifications": "bg-yellow-100 text-yellow-800",
      "templates": "bg-pink-100 text-pink-800",
      "other": "bg-gray-100 text-gray-800",
    };
    return colors[category] || colors.other;
  };

  const getCategoryLabel = (category: string) => {
    const categories = [
      { value: "company-info", label: "Company Information" },
      { value: "capabilities", label: "Capabilities & Services" },
      { value: "case-studies", label: "Case Studies" },
      { value: "technical-specs", label: "Technical Specifications" },
      { value: "certifications", label: "Certifications" },
      { value: "templates", label: "Response Templates" },
      { value: "other", label: "Other" },
    ];
    return categories.find(c => c.value === category)?.label || category;
  };

  if (isLoading) {
    return (
      <div className="space-y-4">
        {[1, 2, 3].map((i) => (
          <div key={i} className="animate-pulse">
            <div className="h-20 bg-gray-100 rounded-lg"></div>
          </div>
        ))}
      </div>
    );
  }

  if (!documents || documents.length === 0) {
    return (
      <div className="text-center py-12">
        <FolderOpen className="mx-auto h-12 w-12 text-gray-400 mb-4" />
        <h3 className="text-lg font-medium text-gray-900 mb-2">No documents found</h3>
        <p className="text-gray-600">Upload your first document to get started</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {documents.map((doc) => (
        <div
          key={doc.id}
          className="border border-gray-200 rounded-lg p-4 hover:bg-gray-50 transition-colors"
        >
          <div className="flex items-start justify-between">
            <div className="flex items-start space-x-4">
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mt-1">
                <FileText className="text-blue-600 h-6 w-6" />
              </div>
              <div className="flex-1">
                <h3 className="font-medium text-gray-900 mb-1">{doc.title}</h3>
                <div className="flex items-center space-x-4 text-xs text-gray-500 mb-2">
                  <span>{doc.fileName}</span>
                  <span>{(doc.fileSize / 1024 / 1024).toFixed(2)} MB</span>
                  <span>{new Date(doc.uploadedAt).toLocaleDateString()}</span>
                </div>
                <Badge className={getCategoryColor(doc.category)}>
                  {getCategoryLabel(doc.category)}
                </Badge>
              </div>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onDelete(doc.id)}
              disabled={deleteLoading}
              className="text-red-600 hover:text-red-700 hover:bg-red-50"
            >
              <Trash2 className="h-4 w-4" />
            </Button>
          </div>
        </div>
      ))}
    </div>
  );
}
