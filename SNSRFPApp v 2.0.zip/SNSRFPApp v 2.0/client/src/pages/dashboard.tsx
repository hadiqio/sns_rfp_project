import { useState } from "react";
import { useQuery } from "@tanstack/react-query";

import WorkflowModal from "@/components/workflow-modal";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useTranslation } from "@/lib/i18n";
import { 
  FileText, 
  CheckCircle, 
  Clock, 
  BookOpen,
  BriefcaseBusiness,
  Construction,
  Cloud,
  Plus
} from "lucide-react";
import { DashboardStats, RfpDocument } from "@/lib/types";

export default function Dashboard() {
  const [isWorkflowModalOpen, setIsWorkflowModalOpen] = useState(false);
  const { t } = useTranslation();

  const { data: stats, isLoading: statsLoading } = useQuery<DashboardStats>({
    queryKey: ["/api/stats"],
  });

  const { data: recentRfps, isLoading: rfpsLoading } = useQuery<RfpDocument[]>({
    queryKey: ["/api/rfp-documents"],
  });

  const handleNewRfp = () => {
    setIsWorkflowModalOpen(true);
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "completed":
        return <CheckCircle className="h-4 w-4 text-green-600" />;
      case "processing":
      case "in-progress":
        return <Clock className="h-4 w-4 text-orange-600" />;
      default:
        return <FileText className="h-4 w-4 text-blue-600" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed":
        return "bg-green-100 text-green-800";
      case "processing":
      case "in-progress":
        return "bg-orange-100 text-orange-800";
      default:
        return "bg-blue-100 text-blue-800";
    }
  };

  return (
    <div className="flex flex-col h-full">
      <div className="flex-1 overflow-y-auto p-6">
        {/* Dashboard Actions */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold text-gray-900 dark:text-white">{t("dashboard")}</h1>
            <p className="text-gray-600 dark:text-gray-300 text-sm mt-1">Manage your RFP responses and company documents</p>
          </div>
          <Button onClick={handleNewRfp} className="flex items-center gap-2">
            <Plus className="h-4 w-4" />
            New RFP
          </Button>
        </div>
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="material-shadow">
            <CardContent className="p-6">
              <div className="flex items-center">
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                  <FileText className="text-blue-600 h-6 w-6" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">{t("totalRfps")}</p>
                  <p className="text-2xl font-bold text-gray-900">
                    {statsLoading ? "..." : stats?.totalRfps || 0}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="material-shadow">
            <CardContent className="p-6">
              <div className="flex items-center">
                <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                  <CheckCircle className="text-green-600 h-6 w-6" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">{t("completedResponses")}</p>
                  <p className="text-2xl font-bold text-gray-900">
                    {statsLoading ? "..." : stats?.completed || 0}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="material-shadow">
            <CardContent className="p-6">
              <div className="flex items-center">
                <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center">
                  <Clock className="text-orange-600 h-6 w-6" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">{t("inProgress")}</p>
                  <p className="text-2xl font-bold text-gray-900">
                    {statsLoading ? "..." : stats?.inProgress || 0}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="material-shadow">
            <CardContent className="p-6">
              <div className="flex items-center">
                <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                  <BookOpen className="text-purple-600 h-6 w-6" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">{t("templates")}</p>
                  <p className="text-2xl font-bold text-gray-900">
                    {statsLoading ? "..." : stats?.templates || 0}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Recent RFPs */}
        <Card className="material-shadow">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-lg font-medium">Recent RFPs</CardTitle>
              <Button variant="ghost" className="text-blue-600 hover:text-blue-700">
                View All
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            {rfpsLoading ? (
              <div className="space-y-4">
                {[1, 2, 3].map((i) => (
                  <div key={i} className="animate-pulse">
                    <div className="h-16 bg-gray-100 rounded-lg"></div>
                  </div>
                ))}
              </div>
            ) : recentRfps && recentRfps.length > 0 ? (
              <div className="space-y-4">
                {recentRfps.slice(0, 3).map((rfp) => (
                  <div
                    key={rfp.id}
                    className="flex items-center justify-between p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors"
                  >
                    <div className="flex items-center space-x-4">
                      <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                        <BriefcaseBusiness className="text-blue-600 h-5 w-5" />
                      </div>
                      <div>
                        <h4 className="font-medium text-gray-900">{rfp.title}</h4>
                        <p className="text-sm text-gray-600">{rfp.clientName}</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-4">
                      <span className={`px-2 py-1 text-xs font-medium rounded-full ${getStatusColor(rfp.status)}`}>
                        {rfp.status}
                      </span>
                      <span className="text-sm text-gray-500">
                        {new Date(rfp.uploadedAt).toLocaleDateString()}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8 text-gray-500">
                No RFP documents uploaded yet
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <WorkflowModal
        isOpen={isWorkflowModalOpen}
        onClose={() => setIsWorkflowModalOpen(false)}
      />
    </div>
  );
}
