import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Settings as SettingsIcon, 
  Database, 
  FileText, 
  Shield, 
  Bell, 
  Download,
  Trash2,
  RefreshCw,
  AlertTriangle
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function Settings() {
  const [generalSettings, setGeneralSettings] = useState({
    autoSave: true,
    notifications: true,
    darkMode: false,
    defaultTemplate: "",
    autoExport: false,
    maxFileSize: "10",
  });

  const [processingSettings, setProcessingSettings] = useState({
    aiEnabled: true,
    contentMatching: true,
    autoGenerate: false,
    qualityCheck: true,
    customPrompts: false,
  });

  const [exportSettings, setExportSettings] = useState({
    defaultFormat: "pdf",
    includeBranding: true,
    watermark: false,
    pageNumbers: true,
    headerFooter: true,
  });

  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: stats } = useQuery({
    queryKey: ["/api/stats"],
  });

  const clearDataMutation = useMutation({
    mutationFn: async (dataType: string) => {
      // In a real implementation, this would call appropriate API endpoints
      await new Promise(resolve => setTimeout(resolve, 1000));
      return { success: true };
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Data cleared successfully",
      });
      queryClient.invalidateQueries();
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to clear data",
        variant: "destructive",
      });
    },
  });

  const exportDataMutation = useMutation({
    mutationFn: async () => {
      // In a real implementation, this would generate and download a data export
      await new Promise(resolve => setTimeout(resolve, 2000));
      return { success: true };
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Data export completed",
      });
    },
  });

  const handleGeneralSettingChange = (key: string, value: any) => {
    setGeneralSettings(prev => ({ ...prev, [key]: value }));
  };

  const handleProcessingSettingChange = (key: string, value: any) => {
    setProcessingSettings(prev => ({ ...prev, [key]: value }));
  };

  const handleExportSettingChange = (key: string, value: any) => {
    setExportSettings(prev => ({ ...prev, [key]: value }));
  };

  const handleClearData = (dataType: string) => {
    const confirmMessage = `Are you sure you want to clear all ${dataType}? This action cannot be undone.`;
    if (window.confirm(confirmMessage)) {
      clearDataMutation.mutate(dataType);
    }
  };

  const handleExportData = () => {
    exportDataMutation.mutate();
  };

  return (
    <div className="flex flex-col h-full">
      <div className="flex-1 overflow-y-auto p-6">
        {/* Page Title */}
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Settings</h1>
          <p className="text-gray-600 dark:text-gray-300 text-sm mt-1">Configure application preferences and manage your data</p>
        </div>
        <Tabs defaultValue="general" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="general">General</TabsTrigger>
            <TabsTrigger value="processing">Processing</TabsTrigger>
            <TabsTrigger value="export">Export</TabsTrigger>
            <TabsTrigger value="data">Data Management</TabsTrigger>
          </TabsList>

          {/* General Settings */}
          <TabsContent value="general" className="mt-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="material-shadow">
                  <CardTitle className="flex items-center space-x-2">
                    <SettingsIcon className="h-5 w-5" />
                    <span>Application Settings</span>
                  </CardTitle>
                <CardContent className="space-y-6">
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label className="text-base">Auto-save documents</Label>
                      <p className="text-sm text-gray-600">
                        Automatically save changes as you work
                      </p>
                    </div>
                    <Switch
                      checked={generalSettings.autoSave}
                      onCheckedChange={(checked) => handleGeneralSettingChange("autoSave", checked)}
                    />
                  </div>

                  <Separator />

                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label className="text-base">Enable notifications</Label>
                      <p className="text-sm text-gray-600">
                        Receive notifications about processing status
                      </p>
                    </div>
                    <Switch
                      checked={generalSettings.notifications}
                      onCheckedChange={(checked) => handleGeneralSettingChange("notifications", checked)}
                    />
                  </div>

                  <Separator />

                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label className="text-base">Dark mode</Label>
                      <p className="text-sm text-gray-600">
                        Use dark theme for the interface
                      </p>
                    </div>
                    <Switch
                      checked={generalSettings.darkMode}
                      onCheckedChange={(checked) => handleGeneralSettingChange("darkMode", checked)}
                    />
                  </div>

                  <Separator />

                  <div className="space-y-2">
                    <Label htmlFor="maxFileSize">Maximum file size (MB)</Label>
                    <Input
                      id="maxFileSize"
                      type="number"
                      value={generalSettings.maxFileSize}
                      onChange={(e) => handleGeneralSettingChange("maxFileSize", e.target.value)}
                      min="1"
                      max="100"
                    />
                    <p className="text-sm text-gray-600">
                      Maximum size for uploaded documents
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card className="material-shadow">
                  <CardTitle className="flex items-center space-x-2">
                    <FileText className="h-5 w-5" />
                    <span>Document Defaults</span>
                  </CardTitle>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="defaultTemplate">Default template</Label>
                    <Select 
                      value={generalSettings.defaultTemplate} 
                      onValueChange={(value) => handleGeneralSettingChange("defaultTemplate", value)}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select default template" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="none">No default template</SelectItem>
                        <SelectItem value="standard">Standard RFP Response</SelectItem>
                        <SelectItem value="technical">Technical Proposal</SelectItem>
                        <SelectItem value="consulting">Consulting Services</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <Separator />

                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label className="text-base">Auto-export completed responses</Label>
                      <p className="text-sm text-gray-600">
                        Automatically export to PDF when finalized
                      </p>
                    </div>
                    <Switch
                      checked={generalSettings.autoExport}
                      onCheckedChange={(checked) => handleGeneralSettingChange("autoExport", checked)}
                    />
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Processing Settings */}
          <TabsContent value="processing" className="mt-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="material-shadow">
                  <CardTitle className="flex items-center space-x-2">
                    <RefreshCw className="h-5 w-5" />
                    <span>AI Processing</span>
                  </CardTitle>
                <CardContent className="space-y-6">
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label className="text-base">Enable AI assistance</Label>
                      <p className="text-sm text-gray-600">
                        Use AI to analyze RFPs and generate responses
                      </p>
                    </div>
                    <Switch
                      checked={processingSettings.aiEnabled}
                      onCheckedChange={(checked) => handleProcessingSettingChange("aiEnabled", checked)}
                    />
                  </div>

                  <Separator />

                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label className="text-base">Smart content matching</Label>
                      <p className="text-sm text-gray-600">
                        Automatically match RFP requirements with company data
                      </p>
                    </div>
                    <Switch
                      checked={processingSettings.contentMatching}
                      onCheckedChange={(checked) => handleProcessingSettingChange("contentMatching", checked)}
                      disabled={!processingSettings.aiEnabled}
                    />
                  </div>

                  <Separator />

                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label className="text-base">Auto-generate responses</Label>
                      <p className="text-sm text-gray-600">
                        Automatically create draft responses upon upload
                      </p>
                    </div>
                    <Switch
                      checked={processingSettings.autoGenerate}
                      onCheckedChange={(checked) => handleProcessingSettingChange("autoGenerate", checked)}
                      disabled={!processingSettings.aiEnabled}
                    />
                  </div>

                  <Separator />

                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label className="text-base">Quality checking</Label>
                      <p className="text-sm text-gray-600">
                        Review generated content for completeness
                      </p>
                    </div>
                    <Switch
                      checked={processingSettings.qualityCheck}
                      onCheckedChange={(checked) => handleProcessingSettingChange("qualityCheck", checked)}
                    />
                  </div>
                </CardContent>
              </Card>

              <Card className="material-shadow">
                  <CardTitle className="flex items-center space-x-2">
                    <Shield className="h-5 w-5" />
                    <span>Security & Privacy</span>
                  </CardTitle>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label className="text-base">Custom AI prompts</Label>
                      <p className="text-sm text-gray-600">
                        Allow custom prompts for AI processing
                      </p>
                    </div>
                    <Switch
                      checked={processingSettings.customPrompts}
                      onCheckedChange={(checked) => handleProcessingSettingChange("customPrompts", checked)}
                    />
                  </div>

                  <Separator />

                  <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                    <div className="flex items-start space-x-3">
                      <AlertTriangle className="h-5 w-5 text-yellow-600 mt-0.5" />
                      <div>
                        <h4 className="text-sm font-medium text-yellow-800">Data Processing Notice</h4>
                        <p className="text-sm text-yellow-700 mt-1">
                          RFP documents may contain sensitive information. Ensure your AI processing
                          complies with your organization's data handling policies.
                        </p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Export Settings */}
          <TabsContent value="export" className="mt-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="material-shadow">
                  <CardTitle className="flex items-center space-x-2">
                    <Download className="h-5 w-5" />
                    <span>Export Preferences</span>
                  </CardTitle>
                <CardContent className="space-y-6">
                  <div className="space-y-2">
                    <Label htmlFor="defaultFormat">Default export format</Label>
                    <Select 
                      value={exportSettings.defaultFormat} 
                      onValueChange={(value) => handleExportSettingChange("defaultFormat", value)}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="pdf">PDF</SelectItem>
                        <SelectItem value="docx">Word Document</SelectItem>
                        <SelectItem value="html">HTML</SelectItem>
                        <SelectItem value="txt">Plain Text</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <Separator />

                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label className="text-base">Include branding</Label>
                      <p className="text-sm text-gray-600">
                        Apply company branding to exported documents
                      </p>
                    </div>
                    <Switch
                      checked={exportSettings.includeBranding}
                      onCheckedChange={(checked) => handleExportSettingChange("includeBranding", checked)}
                    />
                  </div>

                  <Separator />

                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label className="text-base">Add watermark</Label>
                      <p className="text-sm text-gray-600">
                        Include company watermark on documents
                      </p>
                    </div>
                    <Switch
                      checked={exportSettings.watermark}
                      onCheckedChange={(checked) => handleExportSettingChange("watermark", checked)}
                    />
                  </div>

                  <Separator />

                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label className="text-base">Page numbers</Label>
                      <p className="text-sm text-gray-600">
                        Include page numbers in exported PDFs
                      </p>
                    </div>
                    <Switch
                      checked={exportSettings.pageNumbers}
                      onCheckedChange={(checked) => handleExportSettingChange("pageNumbers", checked)}
                    />
                  </div>

                  <Separator />

                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <p className="text-sm text-gray-600">
                        Include header and footer information
                      </p>
                    </div>
                    <Switch
                      checked={exportSettings.headerFooter}
                      onCheckedChange={(checked) => handleExportSettingChange("headerFooter", checked)}
                    />
                  </div>
                </CardContent>
              </Card>

              <Card className="material-shadow">
                  <CardTitle>Export Templates</CardTitle>
                <CardContent className="space-y-4">
                  <p className="text-sm text-gray-600">
                    Customize how your documents appear when exported to different formats.
                  </p>

                  <div className="space-y-3">
                    <Button variant="outline" className="w-full justify-start">
                      <FileText className="mr-2 h-4 w-4" />
                      PDF Template Settings
                    </Button>
                    <Button variant="outline" className="w-full justify-start">
                      <FileText className="mr-2 h-4 w-4" />
                      Word Template Settings
                    </Button>
                    <Button variant="outline" className="w-full justify-start">
                      <FileText className="mr-2 h-4 w-4" />
                      HTML Template Settings
                    </Button>
                  </div>

                  <Separator />

                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h4 className="text-sm font-medium text-blue-800 mb-2">Pro Tip</h4>
                    <p className="text-sm text-blue-700">
                      Consistent formatting across all exports helps maintain professional 
                      appearance and brand recognition.
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Data Management */}
          <TabsContent value="data" className="mt-6">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Data Overview */}
              <Card className="material-shadow">
                  <CardTitle className="flex items-center space-x-2">
                    <Database className="h-5 w-5" />
                    <span>Data Overview</span>
                  </CardTitle>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">RFP Documents</span>
                    <Badge variant="outline">{(stats as any)?.totalRfps || 0}</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">Generated Responses</span>
                    <Badge variant="outline">{((stats as any)?.completed || 0) + ((stats as any)?.inProgress || 0)}</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">Templates</span>
                    <Badge variant="outline">{(stats as any)?.templates || 0}</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">Company Documents</span>
                    <Badge variant="outline">-</Badge>
                  </div>
                </CardContent>
              </Card>

              {/* Data Export */}
              <Card className="material-shadow">
                  <CardTitle>Data Export</CardTitle>
                <CardContent className="space-y-4">
                  <p className="text-sm text-gray-600">
                    Export all your data for backup or migration purposes.
                  </p>

                  <Button
                    onClick={handleExportData}
                    disabled={exportDataMutation.isPending}
                    className="w-full bg-blue-600 hover:bg-blue-700"
                  >
                    <Download className="mr-2 h-4 w-4" />
                    {exportDataMutation.isPending ? "Exporting..." : "Export All Data"}
                  </Button>

                  <p className="text-xs text-gray-500">
                    Exports include all RFPs, responses, templates, and settings in JSON format.
                  </p>
                </CardContent>
              </Card>

              {/* Data Cleanup */}
              <Card className="material-shadow">
                  <CardTitle className="text-red-700">Data Management</CardTitle>
                <CardContent className="space-y-4">
                  <p className="text-sm text-gray-600">
                    Permanently delete data categories. This action cannot be undone.
                  </p>

                  <div className="space-y-2">
                    <Button
                      variant="outline"
                      onClick={() => handleClearData("completed responses")}
                      disabled={clearDataMutation.isPending}
                      className="w-full text-red-600 border-red-200 hover:bg-red-50"
                    >
                      <Trash2 className="mr-2 h-4 w-4" />
                      Clear Completed Responses
                    </Button>

                    <Button
                      variant="outline"
                      onClick={() => handleClearData("processed RFPs")}
                      disabled={clearDataMutation.isPending}
                      className="w-full text-red-600 border-red-200 hover:bg-red-50"
                    >
                      <Trash2 className="mr-2 h-4 w-4" />
                      Clear Processed RFPs
                    </Button>

                    <Button
                      variant="outline"
                      onClick={() => handleClearData("all data")}
                      disabled={clearDataMutation.isPending}
                      className="w-full text-red-600 border-red-200 hover:bg-red-50"
                    >
                      <Trash2 className="mr-2 h-4 w-4" />
                      Clear All Data
                    </Button>
                  </div>

                  <div className="p-3 bg-red-50 border border-red-200 rounded-lg">
                    <div className="flex items-start space-x-2">
                      <AlertTriangle className="h-4 w-4 text-red-600 mt-0.5" />
                      <p className="text-xs text-red-700">
                        Warning: These actions permanently delete data and cannot be undone.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
