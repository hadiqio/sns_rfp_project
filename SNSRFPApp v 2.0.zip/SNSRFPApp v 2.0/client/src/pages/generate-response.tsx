import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { AIEditor } from "@/components/ai-editor";
import { Wand2, FileText, LayoutTemplate, Download, Eye, Brain, CheckCircle, AlertCircle, Loader2, ChevronRight, Check } from "lucide-react";
import { useLocation } from "wouter";
import { Input } from "@/components/ui/input";
import { RfpDocument, Template as TemplateType, RfpResponse } from "@/lib/types";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface AIStatus {
  connected: boolean;
  service: string;
  status: string;
}

interface GenerateResponseData {
  response: RfpResponse;
  analysis: {
    requirements: string[];
    complexity: string;
    categories: string[];
    estimatedHours: number;
    keyTopics: string[];
  };
  generatedResponse: {
    confidence: number;
    usedDocuments: number[];
    usedTemplates: number[];
    recommendations: string[];
  };
}

export default function GenerateResponse() {
  const [selectedRfpId, setSelectedRfpId] = useState<string>("");
  const [selectedTemplateId, setSelectedTemplateId] = useState<string>("");
  const [generatedResponse, setGeneratedResponse] = useState<GenerateResponseData | null>(null);
  const [editedContent, setEditedContent] = useState<string>("");
  const [isEditing, setIsEditing] = useState(false);
  const [aiAnalysis, setAiAnalysis] = useState<any>(null);
  

  
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [, setLocation] = useLocation();

  const { data: rfpDocuments, isLoading: rfpsLoading } = useQuery<RfpDocument[]>({
    queryKey: ["/api/rfp-documents"],
  });

  const { data: templates, isLoading: templatesLoading } = useQuery<TemplateType[]>({
    queryKey: ["/api/templates"],
  });

  const { data: responses, isLoading: responsesLoading } = useQuery<RfpResponse[]>({
    queryKey: ["/api/rfp-responses"],
  });

  const { data: aiStatus, isLoading: aiStatusLoading } = useQuery<AIStatus>({
    queryKey: ["/api/ai/test"],
    refetchInterval: 30000, // Check every 30 seconds
  });

  const generateMutation = useMutation({
    mutationFn: async (data: { rfpDocumentId: number; templateIds?: number[] }) => {
      const response = await apiRequest("POST", "/api/generate-response", data);
      return response.json();
    },
    onSuccess: (data: GenerateResponseData) => {
      toast({
        title: "Success",
        description: "AI-powered RFP response generated successfully",
      });
      setGeneratedResponse(data);
      setEditedContent(data.response.content || "");
      setAiAnalysis(data.analysis);
      queryClient.invalidateQueries({ queryKey: ["/api/rfp-responses"] });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to generate RFP response",
        variant: "destructive",
      });
    },
  });

  const updateMutation = useMutation({
    mutationFn: async (data: { id: number; content: string; status: string }) => {
      const response = await apiRequest("PUT", `/api/rfp-responses/${data.id}`, {
        content: data.content,
        status: data.status,
      });
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Response updated successfully",
      });
      setIsEditing(false);
      queryClient.invalidateQueries({ queryKey: ["/api/rfp-responses"] });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update response",
        variant: "destructive",
      });
    },
  });

  const handleGenerate = () => {
    if (!selectedRfpId) {
      toast({
        title: "Error",
        description: "Please select an RFP document",
        variant: "destructive",
      });
      return;
    }

    const data = {
      rfpDocumentId: parseInt(selectedRfpId),
      templateIds: selectedTemplateId && selectedTemplateId !== "none" ? [parseInt(selectedTemplateId)] : [],
    };

    generateMutation.mutate(data);
  };

  const handleSave = () => {
    if (!generatedResponse) return;

    updateMutation.mutate({
      id: generatedResponse.response.id,
      content: editedContent,
      status: "draft",
    });
  };

  const handleFinalize = () => {
    if (!generatedResponse) return;

    updateMutation.mutate({
      id: generatedResponse.response.id,
      content: editedContent,
      status: "completed",
    });
  };

  const selectedRfp = rfpDocuments?.find(rfp => rfp.id.toString() === selectedRfpId);
  const selectedTemplate = templates?.find(template => template.id.toString() === selectedTemplateId);

  return (
    <div className="flex flex-col h-full">
      <div className="flex-1 overflow-y-auto p-6">
        {/* Page Title */}
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Generate Response</h1>
          <p className="text-gray-600 dark:text-gray-300 text-sm mt-1">Create automated RFP responses using AI and templates</p>
        </div>

        {/* Workflow Stepper */}
        <div className="mb-6">
          <Card className="material-shadow">
            <CardHeader>
              <CardTitle className="text-lg font-semibold text-gray-900 dark:text-white">
                RFP Response Workflow
              </CardTitle>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Follow these steps to create a complete RFP response
              </p>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <div className="flex items-center justify-center w-10 h-10 rounded-full bg-green-500 border-green-500 text-white">
                    <Check className="w-5 h-5" />
                  </div>
                  <div className="ml-3">
                    <p className="text-sm font-medium text-green-600 dark:text-green-400">Upload RFP</p>
                    <p className="text-xs text-gray-500 dark:text-gray-400">Upload and process RFP document</p>
                  </div>
                  <ChevronRight className="w-5 h-5 text-gray-400 mx-4" />
                </div>
                
                <div className="flex items-center">
                  <div className="flex items-center justify-center w-10 h-10 rounded-full bg-green-500 border-green-500 text-white">
                    <Check className="w-5 h-5" />
                  </div>
                  <div className="ml-3">
                    <p className="text-sm font-medium text-green-600 dark:text-green-400">Company Data</p>
                    <p className="text-xs text-gray-500 dark:text-gray-400">Manage company documents</p>
                  </div>
                  <ChevronRight className="w-5 h-5 text-gray-400 mx-4" />
                </div>
                
                <div className="flex items-center">
                  <div className="flex items-center justify-center w-10 h-10 rounded-full border-2 text-white" style={{ backgroundColor: '#36a0d0', borderColor: '#36a0d0' }}>
                    <span className="text-sm font-medium">3</span>
                  </div>
                  <div className="ml-3">
                    <p className="text-sm font-medium text-blue-600 dark:text-blue-400">Generate Response</p>
                    <p className="text-xs text-gray-500 dark:text-gray-400">AI-powered response creation</p>
                  </div>
                  <ChevronRight className="w-5 h-5 text-gray-400 mx-4" />
                </div>
                
                <div className="flex items-center">
                  <div className="flex items-center justify-center w-10 h-10 rounded-full border-2 border-gray-300 text-gray-400">
                    <span className="text-sm font-medium">4</span>
                  </div>
                  <div className="ml-3">
                    <p className="text-sm font-medium text-gray-500 dark:text-gray-400">SNS Branding</p>
                    <p className="text-xs text-gray-500 dark:text-gray-400">Configure branding settings</p>
                  </div>
                  <ChevronRight className="w-5 h-5 text-gray-400 mx-4" />
                </div>
                
                <div className="flex items-center">
                  <div className="flex items-center justify-center w-10 h-10 rounded-full border-2 border-gray-300 text-gray-400">
                    <span className="text-sm font-medium">5</span>
                  </div>
                  <div className="ml-3">
                    <p className="text-sm font-medium text-gray-500 dark:text-gray-400">Preview & Export</p>
                    <p className="text-xs text-gray-500 dark:text-gray-400">Review and export final document</p>
                  </div>
                </div>
              </div>
              
              <div className="mt-6 flex justify-between">
                <Button
                  variant="outline"
                  onClick={() => setLocation('/data-documents')}
                >
                  ← Previous: Company Data
                </Button>
                <Button
                  onClick={() => setLocation('/branding')}
                  style={{ backgroundColor: '#36a0d0' }}
                  className="text-white hover:opacity-90"
                  disabled={!responses || responses.length === 0}
                >
                  Next: SNS Branding →
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
        {/* AI Status Indicator */}
        <Alert className={`mb-6 ${aiStatus?.connected ? 'border-green-200 bg-green-50' : 'border-orange-200 bg-orange-50'}`}>
          <Brain className="h-4 w-4" />
          <AlertDescription className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <span className="font-medium">Azure AI Foundry:</span>
              <Badge variant={aiStatus?.connected ? "default" : "secondary"} className={
                aiStatus?.connected 
                  ? "bg-green-100 text-green-800" 
                  : "bg-orange-100 text-orange-800"
              }>
                {aiStatusLoading ? (
                  <><Loader2 className="h-3 w-3 mr-1 animate-spin" /> Checking...</>
                ) : (
                  <>{aiStatus?.connected ? <CheckCircle className="h-3 w-3 mr-1" /> : <AlertCircle className="h-3 w-3 mr-1" />}
                  {aiStatus?.status || 'Unknown'}</>
                )}
              </Badge>
            </div>
            {aiStatus?.connected && (
              <span className="text-sm text-green-600">AI-powered generation ready</span>
            )}
          </AlertDescription>
        </Alert>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Configuration Panel */}
          <div className="lg:col-span-1 space-y-6">
            {/* RFP Selection */}
            <Card className="material-shadow">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <FileText className="h-5 w-5" />
                  <span>Select RFP</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="rfp-select">RFP Document</Label>
                  <Select value={selectedRfpId} onValueChange={setSelectedRfpId}>
                    <SelectTrigger>
                      <SelectValue placeholder="Choose RFP document" />
                    </SelectTrigger>
                    <SelectContent>
                      {rfpDocuments?.map((rfp) => (
                        <SelectItem key={rfp.id} value={rfp.id.toString()}>
                          {rfp.title} - {rfp.clientName}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {selectedRfp && (
                  <div className="p-3 bg-gray-50 rounded-lg">
                    <h4 className="font-medium text-gray-900 mb-1">{selectedRfp.title}</h4>
                    <p className="text-sm text-gray-600 mb-2">{selectedRfp.clientName}</p>
                    <Badge className={
                      selectedRfp.status === "processed" 
                        ? "bg-green-100 text-green-800" 
                        : "bg-orange-100 text-orange-800"
                    }>
                      {selectedRfp.status}
                    </Badge>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* LayoutTemplate Selection */}
            <Card className="material-shadow">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <LayoutTemplate className="h-5 w-5" />
                  <span>Select LayoutTemplate</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="template-select">Response LayoutTemplate (Optional)</Label>
                  <Select value={selectedTemplateId} onValueChange={setSelectedTemplateId}>
                    <SelectTrigger>
                      <SelectValue placeholder="Choose template (optional)" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">No LayoutTemplate</SelectItem>
                      {templates?.map((template) => (
                        <SelectItem key={template.id} value={template.id.toString()}>
                          {template.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {selectedTemplate && (
                  <div className="p-3 bg-gray-50 rounded-lg">
                    <h4 className="font-medium text-gray-900 mb-1">{selectedTemplate.name}</h4>
                    <p className="text-sm text-gray-600">{selectedTemplate.description}</p>
                  </div>
                )}

                <Button
                  onClick={handleGenerate}
                  disabled={generateMutation.isPending || !selectedRfpId}
                  className="w-full bg-blue-600 hover:bg-blue-700"
                >
                  <Wand2 className="mr-2 h-4 w-4" />
                  {generateMutation.isPending ? "Generating..." : "Generate Response"}
                </Button>
              </CardContent>
            </Card>



            {/* Recent Responses */}
            <Card className="material-shadow">
              <CardHeader>
                <CardTitle>Recent Responses</CardTitle>
              </CardHeader>
              <CardContent>
                {responsesLoading ? (
                  <div className="space-y-2">
                    {[1, 2, 3].map((i) => (
                      <div key={i} className="animate-pulse h-12 bg-gray-100 rounded"></div>
                    ))}
                  </div>
                ) : responses && responses.length > 0 ? (
                  <div className="space-y-3">
                    {responses.slice(0, 5).map((response) => (
                      <div 
                        key={response.id} 
                        className="p-3 border border-gray-200 rounded-lg hover:bg-gray-50 cursor-pointer transition-colors"
                        onClick={() => {
                          // Set the response data structure to match GenerateResponseData
                          setGeneratedResponse({
                            analysis: {
                              requirements: [],
                              complexity: "medium",
                              categories: [],
                              estimatedHours: 0,
                              keyTopics: []
                            },
                            response: response,
                            generatedResponse: response
                          });
                          setEditedContent(response.content || "");
                          setIsEditing(false);
                        }}
                      >
                        <h4 className="font-medium text-gray-900 text-sm mb-1">{response.title}</h4>
                        <div className="flex items-center justify-between">
                          <span className="text-xs text-gray-500">
                            {new Date(response.createdAt).toLocaleDateString()}
                          </span>
                          <Badge className={
                            response.status === "completed" 
                              ? "bg-green-100 text-green-800" 
                              : "bg-orange-100 text-orange-800"
                          }>
                            {response.status}
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-gray-500 text-sm">No responses generated yet</p>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Response Content */}
          <div className="lg:col-span-2">
            <Card className="material-shadow h-full">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle>Generated Response</CardTitle>
                  {generatedResponse && (
                    <div className="flex items-center space-x-2">
                      <Button 
                        variant="outline" 
                        size="sm" 
                        onClick={() => setIsEditing(!isEditing)}
                      >
                        <Eye className="h-4 w-4 mr-1" />
                        {isEditing ? 'Preview' : 'Edit'}
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={handleSave}
                        disabled={updateMutation.isPending}
                      >
                        Save Draft
                      </Button>
                      <Button
                        size="sm"
                        onClick={handleFinalize}
                        disabled={updateMutation.isPending}
                        className="bg-green-600 hover:bg-green-700"
                      >
                        <Download className="mr-2 h-4 w-4" />
                        Finalize
                      </Button>
                    </div>
                  )}
                </div>
              </CardHeader>
              <CardContent className="h-full">
                {!generatedResponse ? (
                  <div className="flex flex-col items-center justify-center h-96 text-center">
                    <Wand2 className="h-16 w-16 text-gray-400 mb-4" />
                    <h3 className="text-lg font-medium text-gray-900 mb-2">No Response Generated</h3>
                    <p className="text-gray-600 mb-4">
                      Select an RFP document and optionally a template, then click "Generate Response" to get started
                    </p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <div>
                        <h4 className="font-medium text-gray-900">{generatedResponse.response.title}</h4>
                        <p className="text-sm text-gray-600">
                          Generated on {new Date(generatedResponse.response.createdAt).toLocaleDateString()}
                        </p>
                      </div>
                      <Badge className={
                        generatedResponse.response.status === "completed" 
                          ? "bg-green-100 text-green-800" 
                          : "bg-orange-100 text-orange-800"
                      }>
                        {generatedResponse.response.status}
                      </Badge>
                    </div>

                    <Separator />

                    {isEditing ? (
                      <AIEditor
                        content={editedContent}
                        onContentChange={setEditedContent}
                        onEditComplete={() => setIsEditing(false)}
                        className="w-full"
                      />
                    ) : (
                      <div className="prose max-w-none">
                        <pre className="whitespace-pre-wrap font-sans text-sm leading-relaxed">
                          {editedContent || (generatedResponse.response.content || "")}
                        </pre>
                      </div>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
