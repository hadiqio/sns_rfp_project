import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";

import FileUpload from "@/components/file-upload";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Trash2, FileText, Clock, CheckCircle, ChevronRight, Check, Sparkles } from "lucide-react";
import { RfpDocument } from "@/lib/types";
import { useLocation } from "wouter";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

// AI Summary Component for processed documents
function DocumentSummary({ document }: { document: RfpDocument }) {
  const [summary, setSummary] = useState<string>("");
  const [isLoading, setIsLoading] = useState(false);
  const [hasLoaded, setHasLoaded] = useState(false);

  const loadSummary = async () => {
    if (document.status !== "processed" || hasLoaded) return;
    
    setIsLoading(true);
    try {
      const response = await apiRequest("POST", `/api/documents/${document.id}/summary`);
      const data = await response.json();
      setSummary(data.summary);
      setHasLoaded(true);
    } catch (error) {
      console.error("Failed to load summary:", error);
      setSummary("Unable to generate summary at this time.");
    } finally {
      setIsLoading(false);
    }
  };

  // Load summary when document is processed
  useEffect(() => {
    if (document.status === "processed" && !hasLoaded) {
      loadSummary();
    }
  }, [document.status, hasLoaded]);

  if (document.status !== "processed") return null;

  return (
    <div className="mt-3 p-3 bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg">
      <div className="flex items-start space-x-2">
        <Sparkles className="w-4 h-4 text-blue-600 dark:text-blue-400 mt-0.5 flex-shrink-0" />
        <div className="flex-1">
          <h4 className="text-sm font-medium text-blue-800 dark:text-blue-200 mb-1">
            AI Summary
          </h4>
          {isLoading ? (
            <div className="flex items-center space-x-2">
              <div className="animate-spin rounded-full h-3 w-3 border-b-2 border-blue-600"></div>
              <span className="text-xs text-blue-600 dark:text-blue-400">Generating summary...</span>
            </div>
          ) : (
            <div className="text-sm text-blue-700 dark:text-blue-300 leading-relaxed">
              {summary.split('\n').map((line, index) => {
                if (line.trim() === '') return null;
                
                // Format section headers with bold text
                if (line.includes('**') && line.includes(':')) {
                  const cleanLine = line.replace(/\*/g, '');
                  return (
                    <div key={index} className="font-semibold text-blue-900 dark:text-blue-100 mt-2 mb-1">
                      {cleanLine}
                    </div>
                  );
                }
                
                // Format bullet points
                if (line.trim().startsWith('- ')) {
                  return (
                    <div key={index} className="ml-2 mb-0.5">
                      {line.trim()}
                    </div>
                  );
                }
                
                // Regular text
                return (
                  <div key={index} className="mb-1">
                    {line.trim()}
                  </div>
                );
              }).filter(Boolean)}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default function UploadRfps() {
  const [uploadForm, setUploadForm] = useState({
    title: "",
    clientName: "",
    file: null as File | null,
  });
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [, setLocation] = useLocation();

  const { data: rfpDocuments, isLoading } = useQuery<RfpDocument[]>({
    queryKey: ["/api/rfp-documents"],
    refetchInterval: 3000, // Refresh every 3 seconds to check for processing completion
  });

  const uploadMutation = useMutation({
    mutationFn: async (data: { title: string; clientName: string; file: File }) => {
      const formData = new FormData();
      formData.append("title", data.title);
      formData.append("clientName", data.clientName);
      formData.append("file", data.file);
      
      // Use fetch directly for file uploads to avoid JSON headers
      const response = await fetch("/api/rfp-documents", {
        method: "POST",
        body: formData,
        credentials: "include",
      });
      
      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`${response.status}: ${errorText}`);
      }
      
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "RFP document uploaded successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/rfp-documents"] });
      setUploadForm({ title: "", clientName: "", file: null });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to upload RFP document",
        variant: "destructive",
      });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/rfp-documents/${id}`);
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "RFP document deleted successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/rfp-documents"] });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to delete RFP document",
        variant: "destructive",
      });
    },
  });

  const handleFileSelect = (file: File) => {
    setUploadForm(prev => ({ ...prev, file }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Debug logging
    console.log("Form submission - uploadForm:", uploadForm);
    
    // Check for required fields
    const missingFields = [];
    if (!uploadForm.title.trim()) missingFields.push("RFP Title");
    if (!uploadForm.clientName.trim()) missingFields.push("Client Name");
    if (!uploadForm.file) missingFields.push("Document File");
    
    console.log("Missing fields:", missingFields);
    
    if (missingFields.length > 0) {
      toast({
        title: "Required Fields Missing",
        description: `Please provide: ${missingFields.join(", ")}`,
        variant: "destructive",
      });
      return;
    }

    uploadMutation.mutate({
      title: uploadForm.title,
      clientName: uploadForm.clientName,
      file: uploadForm.file as File
    });
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "processed":
        return <CheckCircle className="h-4 w-4 text-green-600" />;
      case "processing":
        return (
          <div className="flex items-center">
            <div className="animate-spin rounded-full h-4 w-4 border-2 border-orange-600 border-t-transparent"></div>
          </div>
        );
      default:
        return <FileText className="h-4 w-4 text-blue-600" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "processed":
        return "bg-green-100 text-green-800";
      case "processing":
        return "bg-orange-100 text-orange-800";
      default:
        return "bg-blue-100 text-blue-800";
    }
  };

  return (
    <div className="flex flex-col h-full">
      <div className="flex-1 overflow-y-auto p-6">
        {/* Page Title */}
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Upload RFPs</h1>
          <p className="text-gray-600 dark:text-gray-300 text-sm mt-1">Upload the RFP documents that you need to respond to. These are the client requests that you want to create proposals for.</p>
        </div>

        {/* Workflow Stepper */}
        <div className="mb-6">
          <Card className="material-shadow">
            <CardHeader>
              <CardTitle className="text-lg font-semibold text-gray-900 dark:text-white">
                RFP Response Workflow
              </CardTitle>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Follow these steps to create a complete RFP response
              </p>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <div className="flex items-center justify-center w-10 h-10 rounded-full border-2 text-white" style={{ backgroundColor: '#36a0d0', borderColor: '#36a0d0' }}>
                    <span className="text-sm font-medium">1</span>
                  </div>
                  <div className="ml-3">
                    <p className="text-sm font-medium text-blue-600 dark:text-blue-400">Upload RFP</p>
                    <p className="text-xs text-gray-500 dark:text-gray-400">Upload and process RFP document</p>
                  </div>
                  <ChevronRight className="w-5 h-5 text-gray-400 mx-4" />
                </div>
                
                <div className="flex items-center">
                  <div className="flex items-center justify-center w-10 h-10 rounded-full border-2 border-gray-300 text-gray-400">
                    <span className="text-sm font-medium">2</span>
                  </div>
                  <div className="ml-3">
                    <p className="text-sm font-medium text-gray-500 dark:text-gray-400">Company Data</p>
                    <p className="text-xs text-gray-500 dark:text-gray-400">Manage company documents</p>
                  </div>
                  <ChevronRight className="w-5 h-5 text-gray-400 mx-4" />
                </div>
                
                <div className="flex items-center">
                  <div className="flex items-center justify-center w-10 h-10 rounded-full border-2 border-gray-300 text-gray-400">
                    <span className="text-sm font-medium">3</span>
                  </div>
                  <div className="ml-3">
                    <p className="text-sm font-medium text-gray-500 dark:text-gray-400">Generate Response</p>
                    <p className="text-xs text-gray-500 dark:text-gray-400">AI-powered response creation</p>
                  </div>
                  <ChevronRight className="w-5 h-5 text-gray-400 mx-4" />
                </div>
                
                <div className="flex items-center">
                  <div className="flex items-center justify-center w-10 h-10 rounded-full border-2 border-gray-300 text-gray-400">
                    <span className="text-sm font-medium">4</span>
                  </div>
                  <div className="ml-3">
                    <p className="text-sm font-medium text-gray-500 dark:text-gray-400">SNS Branding</p>
                    <p className="text-xs text-gray-500 dark:text-gray-400">Configure branding settings</p>
                  </div>
                  <ChevronRight className="w-5 h-5 text-gray-400 mx-4" />
                </div>
                
                <div className="flex items-center">
                  <div className="flex items-center justify-center w-10 h-10 rounded-full border-2 border-gray-300 text-gray-400">
                    <span className="text-sm font-medium">5</span>
                  </div>
                  <div className="ml-3">
                    <p className="text-sm font-medium text-gray-500 dark:text-gray-400">Preview & Export</p>
                    <p className="text-xs text-gray-500 dark:text-gray-400">Review and export final document</p>
                  </div>
                </div>
              </div>
              
              <div className="mt-6 flex justify-end">
                <Button
                  onClick={() => setLocation('/data-documents')}
                  style={{ backgroundColor: '#36a0d0' }}
                  className="text-white hover:opacity-90"
                  disabled={!rfpDocuments || rfpDocuments.length === 0}
                >
                  Next: Company Data →
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Upload Form */}
          <div className="lg:col-span-1">
            <Card className="material-shadow">
              <CardHeader>
                <CardTitle>Upload New RFP</CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div>
                    <Label htmlFor="title" className="text-sm font-medium">
                      RFP Title <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="title"
                      value={uploadForm.title}
                      onChange={(e) => setUploadForm(prev => ({ ...prev, title: e.target.value }))}
                      placeholder="Enter RFP title (required)"
                      required
                      className={uploadForm.title.trim() === "" ? "border-red-300 focus:border-red-500" : ""}
                    />
                  </div>

                  <div>
                    <Label htmlFor="clientName" className="text-sm font-medium">
                      Client Name <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="clientName"
                      value={uploadForm.clientName}
                      onChange={(e) => setUploadForm(prev => ({ ...prev, clientName: e.target.value }))}
                      placeholder="Enter client name (required)"
                      required
                      className={uploadForm.clientName.trim() === "" ? "border-red-300 focus:border-red-500" : ""}
                    />
                  </div>

                  <div>
                    <Label className="text-sm font-medium">
                      Document File <span className="text-red-500">*</span>
                    </Label>
                    <FileUpload onFileSelect={handleFileSelect} />
                    {uploadForm.file ? (
                      <p className="text-xs text-green-600 mt-1">✓ {uploadForm.file.name} selected</p>
                    ) : (
                      <p className="text-xs text-gray-500 mt-1">Please select a PDF, DOC, or DOCX file</p>
                    )}
                  </div>

                  <Button
                    type="submit"
                    style={{ backgroundColor: '#36a0d0' }}
                    className="w-full hover:opacity-90 text-white"
                    disabled={uploadMutation.isPending}
                  >
                    {uploadMutation.isPending ? "Uploading..." : "Upload RFP"}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>

          {/* RFP Documents List */}
          <div className="lg:col-span-2">
            <Card className="material-shadow">
              <CardHeader>
                <CardTitle>Uploaded RFP Documents</CardTitle>
              </CardHeader>
              <CardContent>
                {isLoading ? (
                  <div className="space-y-4">
                    {[1, 2, 3].map((i) => (
                      <div key={i} className="animate-pulse">
                        <div className="h-20 bg-gray-100 rounded-lg"></div>
                      </div>
                    ))}
                  </div>
                ) : rfpDocuments && rfpDocuments.length > 0 ? (
                  <div className="space-y-4">
                    {rfpDocuments.map((rfp) => (
                      <div
                        key={rfp.id}
                        className="border border-gray-200 rounded-lg p-4 hover:bg-gray-50 transition-colors"
                      >
                        <div className="flex items-start justify-between">
                          <div className="flex items-start space-x-4">
                            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mt-1">
                              <FileText className="text-blue-600 h-6 w-6" />
                            </div>
                            <div className="flex-1">
                              <h3 className="font-medium text-gray-900 mb-1">{rfp.title}</h3>
                              <p className="text-sm text-gray-600 mb-2">{rfp.clientName}</p>
                              <div className="flex items-center space-x-4 text-xs text-gray-500">
                                <span className="break-all" dir="auto">{rfp.fileName}</span>
                                <span>{(rfp.fileSize / 1024 / 1024).toFixed(2)} MB</span>
                                <span>{new Date(rfp.uploadedAt).toLocaleDateString()}</span>
                              </div>
                            </div>
                          </div>
                          <div className="flex items-center space-x-3">
                            <Badge className={getStatusColor(rfp.status)}>
                              <span className="flex items-center space-x-1">
                                {getStatusIcon(rfp.status)}
                                <span>{rfp.status}</span>
                              </span>
                            </Badge>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => deleteMutation.mutate(rfp.id)}
                              disabled={deleteMutation.isPending}
                              className="text-red-600 hover:text-red-700 hover:bg-red-50"
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                        <DocumentSummary document={rfp} />
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <FileText className="mx-auto h-12 w-12 text-gray-400 mb-4" />
                    <h3 className="text-lg font-medium text-gray-900 mb-2">No RFP documents uploaded</h3>
                    <p className="text-gray-600">Upload your first RFP document to get started</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
