import React from 'react';

export default function TestFileUpload() {
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    console.log("Test file upload - Accept:", e.target.accept);
    if (e.target.files) {
      const files = Array.from(e.target.files);
      console.log("Test files selected:", files.map(f => ({ name: f.name, type: f.type, size: f.size })));
    }
  };

  return (
    <div className="p-4 border border-gray-300 rounded-lg">
      <h3 className="text-lg font-semibold mb-4">Test File Upload</h3>
      
      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium mb-2">PowerPoint and PDF Upload:</label>
          <input
            type="file"
            accept=".pptx,.ppt,.pdf,application/vnd.openxmlformats-officedocument.presentationml.presentation,application/vnd.ms-powerpoint,application/pdf"
            onChange={handleFileChange}
            className="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100"
          />
          <p className="text-xs text-gray-500 mt-1">
            Should accept: .pptx, .ppt, .pdf files
          </p>
        </div>

        <div>
          <label className="block text-sm font-medium mb-2">All Files (for comparison):</label>
          <input
            type="file"
            onChange={handleFileChange}
            className="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-green-50 file:text-green-700 hover:file:bg-green-100"
          />
          <p className="text-xs text-gray-500 mt-1">
            Should accept: All file types
          </p>
        </div>
      </div>
    </div>
  );
}