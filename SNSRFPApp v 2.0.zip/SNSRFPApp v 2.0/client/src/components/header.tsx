import { Button } from "@/components/ui/button";
import { Plus, User, MessageCircle, Zap, Settings } from "lucide-react";
import { ThemeToggle } from "./theme-toggle";
import { LanguageToggle } from "./language-toggle";
import { useTranslation } from "@/lib/i18n";
import { useChatbot } from "@/contexts/ChatbotContext";
import { useQuery } from "@tanstack/react-query";
import { useProcessingStatus } from "@/hooks/useProcessingStatus";

interface HeaderProps {
  title: string;
  subtitle?: string;
  onNewRfp?: () => void;
}

export default function Header({ title, subtitle, onNewRfp }: HeaderProps) {
  const { t } = useTranslation();
  const { isChatbotOpen, onChatbotToggle } = useChatbot();
  const processingStatus = useProcessingStatus();
  
  // Query Azure AI status
  const { data: aiStatus } = useQuery<{ connected: boolean; service: string }>({
    queryKey: ["/api/ai/test"],
    refetchInterval: 30000, // Check every 30 seconds
  });
  
  return (
    <header className="bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 px-6 py-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-medium text-gray-900 dark:text-white">{title}</h2>
          {subtitle && (
            <p className="text-gray-600 dark:text-gray-300 text-sm mt-1">{subtitle}</p>
          )}
        </div>
        <div className="flex items-center space-x-4">
          {onNewRfp && (
            <Button 
              onClick={onNewRfp}
              style={{ backgroundColor: '#36a0d0' }}
              className="text-white hover:opacity-90 material-shadow ripple"
            >
              <Plus className="mr-2 h-4 w-4" />
              {t("uploadNewRfp")}
            </Button>
          )}
          
          {/* Azure AI Status */}
          <div className="flex items-center space-x-2 px-3 py-1 bg-gray-50 dark:bg-gray-700 rounded-full">
            <div className={`w-2 h-2 rounded-full ${aiStatus?.connected ? 'bg-green-500' : 'bg-red-500'}`}></div>
            <Zap className="h-4 w-4 text-gray-600 dark:text-gray-300" />
            <span className="text-xs text-gray-600 dark:text-gray-300 font-medium">
              Azure AI {aiStatus?.connected ? 'Online' : 'Offline'}
            </span>
          </div>
          
          {/* Processing Status */}
          <div className="flex items-center space-x-2 px-3 py-1 bg-gray-50 dark:bg-gray-700 rounded-full">
            <div className={`w-2 h-2 rounded-full ${
              processingStatus.isProcessing 
                ? 'bg-orange-500 animate-pulse' 
                : 'bg-green-500'
            }`}></div>
            <Settings className="h-4 w-4 text-gray-600 dark:text-gray-300" />
            <span className="text-xs text-gray-600 dark:text-gray-300 font-medium">
              {processingStatus.isProcessing 
                ? `Processing (${processingStatus.activeProcesses})` 
                : 'Ready'
              }
            </span>
          </div>
          
          {/* Controls Group */}
          <div className="flex items-center space-x-2">
            <Button
              variant="ghost"
              size="icon"
              onClick={onChatbotToggle}
              className="w-10 h-10 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700"
              title="Toggle AI Assistant"
            >
              <MessageCircle className={`h-5 w-5 ${isChatbotOpen ? 'text-gray-600 dark:text-gray-300' : 'text-gray-600 dark:text-gray-300'}`} style={isChatbotOpen ? { color: '#36a0d0' } : {}} />
            </Button>
            <LanguageToggle />
            <ThemeToggle />
          </div>
          
          {/* Account Icon - Far Right */}
          <div className="w-10 h-10 bg-gray-300 dark:bg-gray-600 rounded-full flex items-center justify-center ml-4">
            <User className="text-gray-600 dark:text-gray-300" />
          </div>
        </div>
      </div>
    </header>
  );
}
