import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { 
  FileText, 
  Upload, 
  BookOpen, 
  Wand2, 
  Eye, 
  Palette, 
  Settings,
  LayoutDashboard,
  Menu,
  X
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { useTranslation } from "@/lib/i18n";
import snsLogo from "@assets/SNS-logo-AI---outlined-(2)_1751266820280.png";

interface SidebarProps {
  isOpen: boolean;
  onToggle: () => void;
}

const getNavigation = (t: any) => [
  { name: t("dashboard"), href: "/", icon: LayoutDashboard },
  { name: t("uploadRfps"), href: "/upload-rfps", icon: Upload, description: t("uploadRfpDescription") },
  { name: t("companyData"), href: "/data-documents", icon: BookOpen, description: t("companyDataDescription") },
  { name: t("generateResponse"), href: "/generate-response", icon: Wand2, description: "Create AI-powered RFP responses" },
  { name: t("previewExport"), href: "/preview-export", icon: Eye, description: "Review and export final proposals" },
  { name: t("snsbranding"), href: "/branding", icon: Palette, description: "Manage brand presentation materials" },
  { name: t("settings"), href: "/settings", icon: Settings, description: "Configure system preferences" },
];

export default function Sidebar({ isOpen, onToggle }: SidebarProps) {
  const [location] = useLocation();
  const { t } = useTranslation();
  const navigation = getNavigation(t);

  return (
    <nav className={cn(
      "bg-white dark:bg-gray-800 material-shadow-lg flex-shrink-0 transition-all duration-300",
      isOpen ? "w-64" : "w-16"
    )}>
      <div className="p-6 border-b border-gray-200 dark:border-gray-700">
        <div className="flex items-center justify-between">
          <div 
            className="flex items-center space-x-3 cursor-pointer hover:opacity-80 transition-opacity"
            onClick={onToggle}
            title={isOpen ? "Click to collapse sidebar" : "Click to expand sidebar"}
          >
            <div className="w-10 h-10 rounded-lg flex items-center justify-center overflow-hidden">
              <img src={snsLogo} alt="SNS Logo" className="w-full h-full object-contain" />
            </div>
            {isOpen && (
              <div>
                <h1 className="text-lg font-medium text-gray-900 dark:text-white">{t("rfpGenerator")}</h1>
                <p className="text-sm text-gray-500">Smart National Solutions</p>
              </div>
            )}
          </div>
          
          {/* Visual Indicator */}
          {isOpen && (
            <div className="text-gray-400 dark:text-gray-500">
              <Menu className="h-4 w-4" />
            </div>
          )}
        </div>
      </div>
      
      <div className="py-4">
        <ul className="space-y-1 px-3">
          {navigation.map((item) => {
            const isActive = location === item.href;
            const linkContent = (
              <Link href={item.href} className={cn(
                "flex items-center px-3 py-2 text-sm font-medium rounded-lg ripple transition-colors",
                isActive 
                  ? "text-white" 
                  : "text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700",
                !isOpen && "justify-center"
              )}
              style={isActive ? { backgroundColor: '#36a0d0' } : {}}>
                <item.icon className={cn("text-lg", isOpen ? "mr-3" : "")} />
                {isOpen && item.name}
              </Link>
            );

            return (
              <li key={item.name}>
                {!isOpen ? (
                  <Tooltip>
                    <TooltipTrigger asChild>
                      {linkContent}
                    </TooltipTrigger>
                    <TooltipContent side="right" className="ml-2">
                      <p>{item.name}</p>
                    </TooltipContent>
                  </Tooltip>
                ) : (
                  linkContent
                )}
              </li>
            );
          })}
        </ul>
      </div>
    </nav>
  );
}
