import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { 
  Edit3, 
  Sparkles, 
  Image, 
  BarChart3, 
  Building2, 
  Palette,
  Loader2,
  CheckCircle,
  AlertCircle,
  Plus,
  ImageIcon,
  FileImage,
  Zap
} from "lucide-react";

interface AIEditorProps {
  content: string;
  onContentChange: (newContent: string) => void;
  onEditComplete?: () => void;
  className?: string;
}

interface VisualAsset {
  type: 'logo' | 'image' | 'diagram' | 'infographic' | 'chart';
  title: string;
  description: string;
  url?: string;
}

export function AIEditor({ content, onContentChange, onEditComplete, className }: AIEditorProps) {
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isVisualDialogOpen, setIsVisualDialogOpen] = useState(false);
  const [editInstruction, setEditInstruction] = useState("");
  const [selectedSection, setSelectedSection] = useState("");
  const [visualDescription, setVisualDescription] = useState("");
  const [selectedVisualType, setSelectedVisualType] = useState<'image' | 'diagram' | 'logo' | 'infographic' | 'chart'>('image');
  const { toast } = useToast();

  // Fetch branding assets
  const { data: brandingAssets } = useQuery<{ assets: VisualAsset[] }>({
    queryKey: ["/api/branding/assets"],
  });

  // AI content editing mutation
  const editContentMutation = useMutation({
    mutationFn: async (data: { originalContent: string; instruction: string; section?: string }) => {
      const response = await apiRequest("POST", "/api/ai/edit-content", data);
      return response.json();
    },
    onSuccess: (data) => {
      console.log("AI Edit Success - Changes:", data.changes);
      console.log("AI Edit Success - New Content Length:", data.editedContent.length);
      onContentChange(data.editedContent);
      setIsEditDialogOpen(false);
      setEditInstruction("");
      setSelectedSection("");
      onEditComplete?.();
      toast({
        title: "Content Updated",
        description: `Applied ${data.changes.length} changes: ${data.changes.join(", ")}`,
      });
    },
    onError: () => {
      toast({
        title: "Edit Failed",
        description: "Unable to edit content. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Visual content generation mutation
  const generateVisualMutation = useMutation({
    mutationFn: async (data: { description: string; type: string }) => {
      const response = await apiRequest("POST", "/api/ai/generate-visual", data);
      return response.json();
    },
    onSuccess: (data) => {
      // Insert visual content description into the document
      const visualPlaceholder = `\n\n[${data.type.toUpperCase()}: ${data.title}]\n${data.description}\n${data.generatedContent}\n\n`;
      onContentChange(content + visualPlaceholder);
      setIsVisualDialogOpen(false);
      setVisualDescription("");
      toast({
        title: "Visual Content Added",
        description: `${data.title} has been added to your document`,
      });
    },
    onError: () => {
      toast({
        title: "Generation Failed",
        description: "Unable to generate visual content. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleEditContent = () => {
    if (!editInstruction.trim()) {
      toast({
        title: "Instruction Required",
        description: "Please provide editing instructions",
        variant: "destructive",
      });
      return;
    }

    editContentMutation.mutate({
      originalContent: content,
      instruction: editInstruction,
      section: selectedSection === "all" ? undefined : selectedSection,
    });
  };

  const handleGenerateVisual = () => {
    if (!visualDescription.trim()) {
      toast({
        title: "Description Required",
        description: "Please describe the visual content you want to generate",
        variant: "destructive",
      });
      return;
    }

    generateVisualMutation.mutate({
      description: visualDescription,
      type: selectedVisualType,
    });
  };

  const insertBrandingAsset = (asset: VisualAsset) => {
    const assetPlaceholder = `\n\n[${asset.type.toUpperCase()}: ${asset.title}]\n${asset.description}\n${asset.url ? `Image: ${asset.url}` : 'Custom branded content'}\n\n`;
    onContentChange(content + assetPlaceholder);
    toast({
      title: "Asset Added",
      description: `${asset.title} has been added to your document`,
    });
  };

  const sections = [
    "Executive Summary",
    "Understanding of Requirements", 
    "Proposed Solution Architecture",
    "Scope of Work & Deliverables",
    "Project Implementation Plan",
    "Team Structure & Expertise",
    "Technology Recommendations",
    "Knowledge Transfer & Training",
    "Risk Management",
    "Conclusion"
  ];

  const visualTypes = [
    { value: 'image', label: 'Image', icon: ImageIcon },
    { value: 'diagram', label: 'Architecture Diagram', icon: BarChart3 },
    { value: 'logo', label: 'Logo', icon: Building2 },
    { value: 'infographic', label: 'Infographic', icon: Palette },
    { value: 'chart', label: 'Chart/Graph', icon: BarChart3 },
  ];

  return (
    <div className={`flex flex-col space-y-4 ${className}`}>
      {/* Editing Toolbar */}
      <div className="flex items-center space-x-2 p-3 bg-gray-50 dark:bg-gray-800 rounded-lg border">
        <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
          <DialogTrigger asChild>
            <Button variant="outline" size="sm">
              <Edit3 className="h-4 w-4 mr-2" />
              AI Edit
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[500px]">
            <DialogHeader>
              <DialogTitle className="flex items-center space-x-2">
                <Sparkles className="h-5 w-5 text-blue-500" />
                <span>AI Content Editor</span>
              </DialogTitle>
              <DialogDescription>
                Describe how you want to modify the content and AI will make the changes for you.
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="section">Focus on Section (Optional)</Label>
                <Select value={selectedSection} onValueChange={setSelectedSection}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select a section to focus on" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Sections</SelectItem>
                    {sections.map((section) => (
                      <SelectItem key={section} value={section}>
                        {section}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="instruction">Editing Instructions</Label>
                <Textarea
                  id="instruction"
                  value={editInstruction}
                  onChange={(e) => setEditInstruction(e.target.value)}
                  placeholder="E.g., 'Make the executive summary more compelling', 'Add more technical details to the architecture section', 'Improve the conclusion with a stronger call to action'"
                  className="min-h-[100px]"
                />
              </div>
            </div>
            <DialogFooter>
              <Button 
                onClick={handleEditContent} 
                disabled={editContentMutation.isPending}
                style={{ backgroundColor: '#36a0d0' }}
                className="text-white hover:opacity-90"
              >
                {editContentMutation.isPending ? (
                  <>
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    Editing...
                  </>
                ) : (
                  <>
                    <Zap className="h-4 w-4 mr-2" />
                    Apply Changes
                  </>
                )}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        <Dialog open={isVisualDialogOpen} onOpenChange={setIsVisualDialogOpen}>
          <DialogTrigger asChild>
            <Button variant="outline" size="sm">
              <Plus className="h-4 w-4 mr-2" />
              Add Visual
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[600px] max-h-[80vh]">
            <DialogHeader>
              <DialogTitle className="flex items-center space-x-2">
                <Image className="h-5 w-5 text-green-500" />
                <span>Add Visual Content</span>
              </DialogTitle>
              <DialogDescription>
                Add images, diagrams, logos, and infographics from your branding materials or generate new visual content.
              </DialogDescription>
            </DialogHeader>
            
            <Tabs defaultValue="generate" className="w-full">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="generate">Generate New</TabsTrigger>
                <TabsTrigger value="branding">From Branding</TabsTrigger>
              </TabsList>
              
              <TabsContent value="generate" className="space-y-4">
                <div>
                  <Label htmlFor="visual-type">Visual Type</Label>
                  <Select value={selectedVisualType} onValueChange={(value) => setSelectedVisualType(value as typeof selectedVisualType)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {visualTypes.map((type) => (
                        <SelectItem key={type.value} value={type.value}>
                          <div className="flex items-center space-x-2">
                            <type.icon className="h-4 w-4" />
                            <span>{type.label}</span>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="visual-description">Description</Label>
                  <Textarea
                    id="visual-description"
                    value={visualDescription}
                    onChange={(e) => setVisualDescription(e.target.value)}
                    placeholder="E.g., 'Create a system architecture diagram showing microservices architecture', 'Generate an infographic about our project timeline', 'Design a chart showing performance improvements'"
                    className="min-h-[100px]"
                  />
                </div>
                <Button 
                  onClick={handleGenerateVisual} 
                  disabled={generateVisualMutation.isPending}
                  style={{ backgroundColor: '#36a0d0' }}
                  className="text-white hover:opacity-90 w-full"
                >
                  {generateVisualMutation.isPending ? (
                    <>
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      Generating...
                    </>
                  ) : (
                    <>
                      <Sparkles className="h-4 w-4 mr-2" />
                      Generate Visual Content
                    </>
                  )}
                </Button>
              </TabsContent>
              
              <TabsContent value="branding" className="space-y-4">
                <ScrollArea className="h-[300px] w-full">
                  {brandingAssets && brandingAssets.assets && brandingAssets.assets.length > 0 ? (
                    <div className="grid gap-3">
                      {brandingAssets.assets.map((asset: VisualAsset, index: number) => (
                        <Card key={index} className="cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors">
                          <CardContent className="p-4">
                            <div className="flex items-center justify-between">
                              <div className="flex items-center space-x-3">
                                <div className="w-10 h-10 bg-blue-100 dark:bg-blue-900 rounded-lg flex items-center justify-center">
                                  {asset.type === 'logo' && <Building2 className="h-5 w-5 text-blue-600" />}
                                  {asset.type === 'image' && <FileImage className="h-5 w-5 text-blue-600" />}
                                  {asset.type === 'diagram' && <BarChart3 className="h-5 w-5 text-blue-600" />}
                                  {asset.type === 'infographic' && <Palette className="h-5 w-5 text-blue-600" />}
                                  {asset.type === 'chart' && <BarChart3 className="h-5 w-5 text-blue-600" />}
                                </div>
                                <div>
                                  <h4 className="font-medium">{asset.title}</h4>
                                  <p className="text-sm text-gray-600 dark:text-gray-400">{asset.description}</p>
                                </div>
                              </div>
                              <Button 
                                size="sm" 
                                onClick={() => insertBrandingAsset(asset)}
                                style={{ backgroundColor: '#36a0d0' }}
                                className="text-white hover:opacity-90"
                              >
                                Insert
                              </Button>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  ) : (
                    <div className="flex flex-col items-center justify-center h-full text-gray-500">
                      <FileImage className="h-12 w-12 mb-4 text-gray-400" />
                      <p className="text-center">No branding assets available</p>
                      <p className="text-sm text-center">Upload brand presentations in the Branding section</p>
                    </div>
                  )}
                </ScrollArea>
              </TabsContent>
            </Tabs>
          </DialogContent>
        </Dialog>

        <Separator orientation="vertical" className="h-6" />
        
        <div className="flex items-center space-x-2 text-sm text-gray-600 dark:text-gray-400">
          <Sparkles className="h-4 w-4" />
          <span>AI-Powered Editing</span>
        </div>
      </div>

      {/* Content Editor */}
      <Textarea
        value={content}
        onChange={(e) => onContentChange(e.target.value)}
        className="min-h-[500px] font-mono text-sm resize-none"
        placeholder="Your RFP response content will appear here..."
      />
    </div>
  );
}