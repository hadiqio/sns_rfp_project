import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Upload, Check } from "lucide-react";
import FileUpload from "./file-upload";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface WorkflowModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const steps = [
  { id: 1, name: "Upload RFP", description: "Select the RFP document" },
  { id: 2, name: "Parse & Analyze", description: "Extract content and analyze requirements" },
  { id: 3, name: "Generate Response", description: "Create automated response" },
  { id: 4, name: "Review & Export", description: "Review and export final document" },
];

export default function WorkflowModal({ isOpen, onClose }: WorkflowModalProps) {
  const [currentStep, setCurrentStep] = useState(1);
  const [formData, setFormData] = useState({
    title: "",
    clientName: "",
    file: null as File | null,
  });
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const uploadMutation = useMutation({
    mutationFn: async (data: { title: string; clientName: string; file: File }) => {
      const formData = new FormData();
      formData.append("title", data.title);
      formData.append("clientName", data.clientName);
      formData.append("file", data.file);
      
      return apiRequest("POST", "/api/rfp-documents", formData);
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "RFP document uploaded successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/rfp-documents"] });
      setCurrentStep(2);
      // Simulate processing steps
      setTimeout(() => setCurrentStep(3), 2000);
      setTimeout(() => setCurrentStep(4), 4000);
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to upload RFP document",
        variant: "destructive",
      });
    },
  });

  const handleFileSelect = (file: File) => {
    setFormData(prev => ({ ...prev, file }));
  };

  const handleSubmit = () => {
    if (!formData.file || !formData.title || !formData.clientName) {
      toast({
        title: "Error",
        description: "Please fill in all fields and select a file",
        variant: "destructive",
      });
      return;
    }

    uploadMutation.mutate(formData);
  };

  const handleClose = () => {
    setCurrentStep(1);
    setFormData({ title: "", clientName: "", file: null });
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-hidden">
        <DialogHeader>
          <DialogTitle className="text-xl font-medium">RFP Response Generator</DialogTitle>
        </DialogHeader>
        
        {/* Progress Steps */}
        <div className="flex items-center justify-between mb-8 px-4">
          {steps.map((step, index) => (
            <div key={step.id} className="flex items-center">
              <div className="flex items-center space-x-4">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
                  currentStep >= step.id 
                    ? "bg-blue-600 text-white" 
                    : "bg-gray-300 text-gray-600"
                }`}>
                  {currentStep > step.id ? <Check className="h-4 w-4" /> : step.id}
                </div>
                <span className={`text-sm font-medium ${
                  currentStep >= step.id ? "text-gray-900" : "text-gray-600"
                }`}>
                  {step.name}
                </span>
              </div>
              {index < steps.length - 1 && (
                <div className="w-16 h-px bg-gray-300 mx-4" />
              )}
            </div>
          ))}
        </div>

        {/* Step Content */}
        <div className="bg-gray-50 rounded-xl p-8">
          {currentStep === 1 && (
            <div className="text-center">
              <Upload className="mx-auto h-16 w-16 text-blue-600 mb-4" />
              <h4 className="text-lg font-medium text-gray-900 mb-2">Upload RFP Document</h4>
              <p className="text-gray-600 mb-6">
                Select the RFP document you'd like to respond to. Our system supports PDF and Word documents.
              </p>
              
              <div className="space-y-4 mb-6">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="title">RFP Title</Label>
                    <Input
                      id="title"
                      value={formData.title}
                      onChange={(e) => setFormData(prev => ({ ...prev, title: e.target.value }))}
                      placeholder="Enter RFP title"
                    />
                  </div>
                  <div>
                    <Label htmlFor="clientName">Client Name</Label>
                    <Input
                      id="clientName"
                      value={formData.clientName}
                      onChange={(e) => setFormData(prev => ({ ...prev, clientName: e.target.value }))}
                      placeholder="Enter client name"
                    />
                  </div>
                </div>
                
                <FileUpload onFileSelect={handleFileSelect} />
              </div>

              <div className="flex justify-center space-x-4">
                <Button variant="outline" onClick={handleClose}>
                  Cancel
                </Button>
                <Button 
                  onClick={handleSubmit}
                  disabled={uploadMutation.isPending}
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  {uploadMutation.isPending ? "Uploading..." : "Upload & Continue"}
                </Button>
              </div>
            </div>
          )}

          {currentStep === 2 && (
            <div className="text-center">
              <div className="animate-spin h-16 w-16 border-4 border-blue-600 border-t-transparent rounded-full mx-auto mb-4" />
              <h4 className="text-lg font-medium text-gray-900 mb-2">Parsing & Analyzing</h4>
              <p className="text-gray-600">
                We're extracting content from your RFP document and analyzing the requirements...
              </p>
            </div>
          )}

          {currentStep === 3 && (
            <div className="text-center">
              <div className="animate-spin h-16 w-16 border-4 border-blue-600 border-t-transparent rounded-full mx-auto mb-4" />
              <h4 className="text-lg font-medium text-gray-900 mb-2">Generating Response</h4>
              <p className="text-gray-600">
                Creating your automated RFP response using our templates and company data...
              </p>
            </div>
          )}

          {currentStep === 4 && (
            <div className="text-center">
              <Check className="mx-auto h-16 w-16 text-green-600 mb-4" />
              <h4 className="text-lg font-medium text-gray-900 mb-2">Response Generated</h4>
              <p className="text-gray-600 mb-6">
                Your RFP response has been successfully generated and is ready for review.
              </p>
              <Button onClick={handleClose} className="bg-blue-600 hover:bg-blue-700">
                Continue to Review
              </Button>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
