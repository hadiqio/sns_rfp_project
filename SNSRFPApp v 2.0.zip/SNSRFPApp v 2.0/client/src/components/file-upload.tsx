import { useState, useCallback } from "react";
import { Upload, File, X } from "lucide-react";
import { cn } from "@/lib/utils";
import { FileUploadProps } from "@/lib/types";

export default function FileUpload({
  onFileSelect,
  accept = ".pdf,.doc,.docx",
  maxSize = 10 * 1024 * 1024, // 10MB
  multiple = false,
  className,
}: FileUploadProps) {
  const [isDragOver, setIsDragOver] = useState(false);
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    
    const files = Array.from(e.dataTransfer.files);
    handleFiles(files);
  }, []);

  const handleFileChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    console.log("File input clicked, accept attribute:", e.target.accept);
    if (e.target.files) {
      const files = Array.from(e.target.files);
      console.log("Selected files:", files.map(f => ({ name: f.name, type: f.type })));
      handleFiles(files);
    }
  }, []);

  const handleFiles = (files: File[]) => {
    try {
      const validFiles = files.filter(file => {
        if (file.size > maxSize) {
          alert(`File ${file.name} is too large. Maximum size is ${maxSize / 1024 / 1024}MB`);
          return false;
        }
        return true;
      });

      if (multiple) {
        setSelectedFiles(prev => [...prev, ...validFiles]);
        validFiles.forEach(file => {
          try {
            onFileSelect(file);
          } catch (error) {
            console.error("Error in onFileSelect callback:", error);
          }
        });
      } else if (validFiles.length > 0) {
        setSelectedFiles([validFiles[0]]);
        try {
          onFileSelect(validFiles[0]);
        } catch (error) {
          console.error("Error in onFileSelect callback:", error);
        }
      }
    } catch (error) {
      console.error("Error handling files:", error);
    }
  };

  const removeFile = (index: number) => {
    setSelectedFiles(prev => prev.filter((_, i) => i !== index));
  };

  return (
    <div className={cn("space-y-4", className)}>
      <div
        className={cn(
          "border-2 border-dashed rounded-lg p-6 text-center transition-colors cursor-pointer",
          isDragOver 
            ? "border-blue-600 bg-blue-50" 
            : "border-gray-300 hover:border-blue-600"
        )}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        onClick={() => document.getElementById('file-input')?.click()}
      >
        <Upload className="mx-auto h-12 w-12 text-gray-400 mb-4" />
        <p className="text-sm text-gray-600 mb-2">
          Drag & drop files here, or click to select
        </p>
        <p className="text-xs text-gray-500 mb-4">
          {accept.split(',').join(', ')} up to {maxSize / 1024 / 1024}MB
        </p>
        <input
          id="file-input"
          type="file"
          className="hidden"
          accept={accept}
          multiple={multiple}
          onChange={handleFileChange}
        />
      </div>

      {selectedFiles.length > 0 && (
        <div className="space-y-2">
          <h4 className="text-sm font-medium text-gray-700">Selected Files:</h4>
          {selectedFiles.map((file, index) => (
            <div key={index} className="flex items-center justify-between p-2 bg-gray-50 rounded-lg">
              <div className="flex items-center space-x-2">
                <File className="h-4 w-4 text-gray-500" />
                <span className="text-sm text-gray-700">{file.name}</span>
                <span className="text-xs text-gray-500">
                  ({(file.size / 1024 / 1024).toFixed(2)} MB)
                </span>
              </div>
              <button
                onClick={() => removeFile(index)}
                className="text-gray-400 hover:text-red-500"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
