import { Check, ChevronRight } from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useLocation } from "wouter";

interface WorkflowStep {
  id: string;
  title: string;
  description: string;
  path: string;
  completed: boolean;
  current: boolean;
}

interface WorkflowStepperProps {
  steps: WorkflowStep[];
  onStepClick: (path: string) => void;
}

export function WorkflowStepper({ steps, onStepClick }: WorkflowStepperProps) {
  return (
    <Card className="material-shadow mb-6">
      <CardHeader>
        <CardTitle className="text-lg font-semibold text-gray-900 dark:text-white">
          RFP Response Workflow
        </CardTitle>
        <p className="text-sm text-gray-600 dark:text-gray-400">
          Follow these steps to create a complete RFP response
        </p>
      </CardHeader>
      <CardContent>
        <div className="flex items-center justify-between">
          {steps.map((step, index) => (
            <div key={step.id} className="flex items-center">
              {/* Step Circle */}
              <div
                className={cn(
                  "flex items-center justify-center w-10 h-10 rounded-full border-2 cursor-pointer transition-all",
                  step.completed
                    ? "bg-green-500 border-green-500 text-white"
                    : step.current
                    ? "border-blue-500 text-blue-500"
                    : "border-gray-300 text-gray-400"
                )}
                onClick={() => onStepClick(step.path)}
              >
                {step.completed ? (
                  <Check className="w-5 h-5" />
                ) : (
                  <span className="text-sm font-medium">{index + 1}</span>
                )}
              </div>

              {/* Step Label */}
              <div className="ml-3 flex-1">
                <button
                  onClick={() => onStepClick(step.path)}
                  className="text-left"
                >
                  <p
                    className={cn(
                      "text-sm font-medium",
                      step.current
                        ? "text-blue-600 dark:text-blue-400"
                        : step.completed
                        ? "text-green-600 dark:text-green-400"
                        : "text-gray-500 dark:text-gray-400"
                    )}
                  >
                    {step.title}
                  </p>
                  <p className="text-xs text-gray-500 dark:text-gray-400">
                    {step.description}
                  </p>
                </button>
              </div>

              {/* Arrow */}
              {index < steps.length - 1 && (
                <ChevronRight className="w-5 h-5 text-gray-400 mx-4" />
              )}
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}

interface WorkflowNavigationProps {
  currentStep: string;
  onNext?: () => void;
  onPrevious?: () => void;
  nextLabel?: string;
  previousLabel?: string;
  isNextDisabled?: boolean;
}

export function WorkflowNavigation({
  currentStep,
  onNext,
  onPrevious,
  nextLabel = "Next Step",
  previousLabel = "Previous Step",
  isNextDisabled = false,
}: WorkflowNavigationProps) {
  return (
    <div className="flex justify-between items-center pt-6 border-t border-gray-200 dark:border-gray-700">
      <div>
        {onPrevious && (
          <Button
            variant="outline"
            onClick={onPrevious}
            className="flex items-center space-x-2"
          >
            <span>← {previousLabel}</span>
          </Button>
        )}
      </div>
      <div>
        {onNext && (
          <Button
            onClick={onNext}
            disabled={isNextDisabled}
            style={{ backgroundColor: '#36a0d0' }}
            className="flex items-center space-x-2 text-white hover:opacity-90"
          >
            <span>{nextLabel} →</span>
          </Button>
        )}
      </div>
    </div>
  );
}