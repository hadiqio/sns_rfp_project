import { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';

interface ProcessingStatusInfo {
  isProcessing: boolean;
  activeProcesses: number;
  lastActivity: Date | null;
}

export function useProcessingStatus() {
  const [processingInfo, setProcessingInfo] = useState<ProcessingStatusInfo>({
    isProcessing: false,
    activeProcesses: 0,
    lastActivity: null
  });

  // Query for RFP documents to check if any are processing
  const { data: rfpDocuments } = useQuery<any[]>({
    queryKey: ['/api/rfp-documents'],
    refetchInterval: 5000, // Check every 5 seconds
  });

  // Query for RFP responses to check if any are being generated
  const { data: rfpResponses } = useQuery<any[]>({
    queryKey: ['/api/rfp-responses'],
    refetchInterval: 5000,
  });

  useEffect(() => {
    if (!rfpDocuments && !rfpResponses) return;

    const processingDocs = rfpDocuments?.filter(doc => 
      doc.status === 'processing' || doc.status === 'uploading'
    ) || [];

    const processingResponses = rfpResponses?.filter(response => 
      response.status === 'generating' || response.status === 'processing'
    ) || [];

    const totalProcessing = processingDocs.length + processingResponses.length;
    const isCurrentlyProcessing = totalProcessing > 0;

    setProcessingInfo({
      isProcessing: isCurrentlyProcessing,
      activeProcesses: totalProcessing,
      lastActivity: isCurrentlyProcessing ? new Date() : processingInfo.lastActivity
    });
  }, [rfpDocuments, rfpResponses]);

  return processingInfo;
}