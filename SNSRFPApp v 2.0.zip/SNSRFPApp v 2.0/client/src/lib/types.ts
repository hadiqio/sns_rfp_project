import { 
  RfpDocument, 
  CompanyDocument, 
  RfpResponse, 
  Template, 
  BrandingSettings 
} from "@shared/schema";

export type { 
  RfpDocument, 
  CompanyDocument, 
  RfpResponse, 
  Template, 
  BrandingSettings 
};

export interface DashboardStats {
  totalRfps: number;
  completed: number;
  inProgress: number;
  templates: number;
}

export interface FileUploadProps {
  onFileSelect: (file: File) => void;
  accept?: string;
  maxSize?: number;
  multiple?: boolean;
  className?: string;
}

export interface ProcessingStatus {
  documentParser: "online" | "offline" | "processing";
  aiContentMatcher: "online" | "offline" | "processing";
  pdfGenerator: "online" | "offline" | "processing";
}
