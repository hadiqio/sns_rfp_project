import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';

export type Language = 'en' | 'ar';

interface LanguageStore {
  language: Language;
  setLanguage: (lang: Language) => void;
  isRTL: boolean;
}

export const useLanguage = create<LanguageStore>()(
  persist(
    (set, get) => ({
      language: 'en',
      setLanguage: (lang: Language) => {
        set({ language: lang, isRTL: lang === 'ar' });
        
        // Update document direction and language
        if (typeof document !== 'undefined') {
          document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
          document.documentElement.lang = lang;
        }
      },
      isRTL: false,
    }),
    {
      name: 'language-storage',
      storage: createJSONStorage(() => localStorage),
    }
  )
);

// Translation dictionary
export const translations = {
  en: {
    // Navigation
    dashboard: "Dashboard",
    uploadRfps: "Upload RFPs",
    companyData: "Company Data",
    generateResponse: "Generate Response",
    previewExport: "Preview & Export",
    snsbranding: "SNS Branding",
    settings: "Settings",
    
    // Dashboard
    welcomeTo: "Welcome to",
    rfpGenerator: "RFP Generator",
    totalRfps: "Total RFPs",
    completedResponses: "Completed Responses",
    inProgress: "In Progress",
    templates: "Templates",
    uploadNewRfp: "Upload New RFP",
    quickActions: "Quick Actions",
    recentActivity: "Recent Activity",
    
    // Upload RFPs
    uploadRfpDocuments: "Upload RFP Documents",
    uploadRfpDescription: "Upload RFP documents you need to respond to",
    selectFile: "Select File",
    title: "Title",
    clientName: "Client Name",
    upload: "Upload",
    processing: "Processing",
    completed: "Completed",
    failed: "Failed",
    
    // Company Data
    companyDocuments: "Company Documents",
    companyDataDescription: "Upload your company documents and capabilities",
    category: "Category",
    capabilities: "Capabilities",
    portfolio: "Portfolio",
    certifications: "Certifications",
    experience: "Experience",
    team: "Team",
    
    // Generate Response
    generateAiResponse: "Generate AI Response",
    selectRfpDocument: "Select RFP Document",
    selectTemplate: "Select Template",
    generate: "Generate",
    projectPricing: "Project Pricing",
    duration: "Duration (Months)",
    totalConsultants: "Total Consultants",
    deliveryModel: "Delivery Model",
    currency: "Currency",
    ratePerConsultant: "Rate per Consultant/Month",
    consultantBreakdown: "Consultant Breakdown",
    role: "Role",
    count: "Count",
    rate: "Rate",
    additionalCosts: "Additional Costs",
    item: "Item",
    cost: "Cost",
    taxRate: "Tax Rate (%)",
    subtotal: "Subtotal",
    tax: "Tax",
    total: "Total",
    savePricing: "Save Pricing",
    
    // Authentication
    createAccount: "Create Account",
    registerDescription: "Register for SNS RFP Generator to start creating professional proposals",
    emailAddress: "Email Address",
    firstName: "First Name",
    lastName: "Last Name (Optional)",
    welcomeBack: "Welcome Back",
    signInDescription: "Sign in to your SNS RFP Generator account",
    password: "Password",
    signIn: "Sign In",
    createOne: "Create one here",
    forgotPassword: "Forgot your password?",
    dontHaveAccount: "Don't have an account?",
    alreadyHaveAccount: "Already have an account?",
    signInHere: "Sign in here",
    
    // Set Password
    setYourPassword: "Set Your Password",
    setPasswordDescription: "Create a secure password to complete your account setup",
    confirmPassword: "Confirm Password",
    passwordRequirements: "Password Requirements:",
    atLeast6Characters: "• At least 6 characters long",
    betterSecurity: "• For better security, use uppercase, lowercase, numbers, and symbols",
    completeAccountSetup: "Complete Account Setup",
    
    // Common
    loading: "Loading",
    save: "Save",
    cancel: "Cancel",
    delete: "Delete",
    edit: "Edit",
    close: "Close",
    next: "Next",
    previous: "Previous",
    search: "Search",
    filter: "Filter",
    sort: "Sort",
    
    // Status
    online: "Online",
    offline: "Offline",
    connected: "Connected",
    disconnected: "Disconnected",
    
    // File Types
    pdf: "PDF",
    word: "Word Document",
    excel: "Excel",
    powerpoint: "PowerPoint",
    
    // Currency
    usd: "USD - US Dollar ($)",
    eur: "EUR - Euro (€)",
    sar: "SAR - Saudi Riyal (ر.س)",
    
    // Delivery Models
    onsite: "Onsite",
    offshore: "Offshore",
    hybrid: "Hybrid",
  },
  ar: {
    // Navigation
    dashboard: "لوحة التحكم",
    uploadRfps: "رفع طلبات العروض",
    companyData: "بيانات الشركة",
    generateResponse: "إنشاء الاستجابة",
    previewExport: "معاينة وتصدير",
    snsbranding: "علامة SNS التجارية",
    settings: "الإعدادات",
    
    // Dashboard
    welcomeTo: "مرحباً بك في",
    rfpGenerator: "مولد طلبات العروض",
    totalRfps: "إجمالي طلبات العروض",
    completedResponses: "الاستجابات المكتملة",
    inProgress: "قيد التنفيذ",
    templates: "القوالب",
    uploadNewRfp: "رفع طلب عرض جديد",
    quickActions: "الإجراءات السريعة",
    recentActivity: "النشاط الأخير",
    
    // Upload RFPs
    uploadRfpDocuments: "رفع مستندات طلبات العروض",
    uploadRfpDescription: "رفع مستندات طلبات العروض التي تحتاج للرد عليها",
    selectFile: "اختيار ملف",
    title: "العنوان",
    clientName: "اسم العميل",
    upload: "رفع",
    processing: "معالجة",
    completed: "مكتمل",
    failed: "فشل",
    
    // Company Data
    companyDocuments: "مستندات الشركة",
    companyDataDescription: "رفع مستندات وقدرات شركتك",
    category: "الفئة",
    capabilities: "القدرات",
    portfolio: "المحفظة",
    certifications: "الشهادات",
    experience: "الخبرة",
    team: "الفريق",
    
    // Generate Response
    generateAiResponse: "إنشاء استجابة بالذكاء الاصطناعي",
    selectRfpDocument: "اختيار مستند طلب العرض",
    selectTemplate: "اختيار القالب",
    generate: "إنشاء",
    projectPricing: "تسعير المشروع",
    duration: "المدة (بالأشهر)",
    totalConsultants: "إجمالي الاستشاريين",
    deliveryModel: "نموذج التسليم",
    currency: "العملة",
    ratePerConsultant: "السعر لكل استشاري/شهر",
    consultantBreakdown: "تفصيل الاستشاريين",
    role: "الدور",
    count: "العدد",
    rate: "السعر",
    additionalCosts: "التكاليف الإضافية",
    item: "البند",
    cost: "التكلفة",
    taxRate: "معدل الضريبة (%)",
    subtotal: "المجموع الفرعي",
    tax: "الضريبة",
    total: "الإجمالي",
    savePricing: "حفظ التسعير",
    
    // Authentication
    createAccount: "إنشاء حساب",
    registerDescription: "سجل في مولد طلبات العروض SNS لبدء إنشاء عروض احترافية",
    emailAddress: "عنوان البريد الإلكتروني",
    firstName: "الاسم الأول",
    lastName: "اسم العائلة (اختياري)",
    welcomeBack: "مرحباً بعودتك",
    signInDescription: "سجل الدخول إلى حساب مولد طلبات العروض SNS",
    password: "كلمة المرور",
    signIn: "تسجيل الدخول",
    createOne: "إنشاء حساب هنا",
    forgotPassword: "نسيت كلمة المرور؟",
    dontHaveAccount: "ليس لديك حساب؟",
    alreadyHaveAccount: "لديك حساب بالفعل؟",
    signInHere: "سجل الدخول هنا",
    
    // Set Password
    setYourPassword: "تعيين كلمة المرور",
    setPasswordDescription: "أنشئ كلمة مرور آمنة لإكمال إعداد حسابك",
    confirmPassword: "تأكيد كلمة المرور",
    passwordRequirements: "متطلبات كلمة المرور:",
    atLeast6Characters: "• على الأقل 6 أحرف",
    betterSecurity: "• للحصول على أمان أفضل، استخدم أحرف كبيرة وصغيرة وأرقام ورموز",
    completeAccountSetup: "إكمال إعداد الحساب",
    
    // Common
    loading: "جاري التحميل",
    save: "حفظ",
    cancel: "إلغاء",
    delete: "حذف",
    edit: "تعديل",
    close: "إغلاق",
    next: "التالي",
    previous: "السابق",
    search: "بحث",
    filter: "تصفية",
    sort: "ترتيب",
    
    // Status
    online: "متصل",
    offline: "غير متصل",
    connected: "متصل",
    disconnected: "منقطع",
    
    // File Types
    pdf: "PDF",
    word: "مستند Word",
    excel: "Excel",
    powerpoint: "PowerPoint",
    
    // Currency
    usd: "دولار أمريكي ($)",
    eur: "يورو (€)",
    sar: "ريال سعودي (ر.س)",
    
    // Delivery Models
    onsite: "في الموقع",
    offshore: "خارجي",
    hybrid: "مختلط",
  }
};

// Translation hook
export const useTranslation = () => {
  const { language } = useLanguage();
  
  const t = (key: keyof typeof translations.en): string => {
    return translations[language][key] || translations.en[key] || key;
  };
  
  return { t, language };
};