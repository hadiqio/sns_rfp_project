import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "@/components/theme-provider";
import { useLanguage } from "@/lib/i18n";
import NotFound from "@/pages/not-found";
import Dashboard from "@/pages/dashboard";
import UploadRfps from "@/pages/upload-rfps";
import DataDocuments from "@/pages/data-documents";
import GenerateResponse from "@/pages/generate-response";
import PreviewExport from "@/pages/preview-export";
import Branding from "@/pages/branding";
import Settings from "@/pages/settings";
import Register from "@/pages/register";
import Login from "@/pages/login";
import SetPassword from "@/pages/set-password";
import Sidebar from "@/components/sidebar";
import Header from "@/components/header";
import { Chatbot } from "@/components/chatbot";
import { ChatbotProvider } from "@/contexts/ChatbotContext";
import { WorkflowProvider } from "@/contexts/WorkflowContext";
import { useState, useEffect } from "react";

function Router() {
  return (
    <Switch>
      {/* Authentication routes */}
      <Route path="/register" component={Register} />
      <Route path="/login" component={Login} />
      <Route path="/set-password" component={SetPassword} />
      
      {/* Protected routes */}
      <Route path="/" component={Dashboard} />
      <Route path="/upload-rfps" component={UploadRfps} />
      <Route path="/data-documents" component={DataDocuments} />
      <Route path="/generate-response" component={GenerateResponse} />
      <Route path="/preview-export" component={PreviewExport} />
      <Route path="/branding" component={Branding} />
      <Route path="/settings" component={Settings} />
      <Route component={NotFound} />
    </Switch>
  );
}

function MainContent({ isChatbotOpen, onChatbotToggle, onChatbotClose }: { 
  isChatbotOpen: boolean; 
  onChatbotToggle: () => void;
  onChatbotClose: () => void;
}) {
  return (
    <div className="flex h-full">
      <div className={`flex-1 h-full transition-all duration-300 ${isChatbotOpen ? 'pr-4' : ''}`}>
        <Router />
      </div>
      {isChatbotOpen && (
        <div className="w-80 h-full border-l border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 flex flex-col pt-4">
          <Chatbot onClose={onChatbotClose} />
        </div>
      )}
    </div>
  );
}

function App() {
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [isChatbotOpen, setIsChatbotOpen] = useState(false);
  const { language, isRTL } = useLanguage();

  // Initialize document direction on app load
  useEffect(() => {
    if (typeof document !== 'undefined') {
      document.documentElement.dir = isRTL ? 'rtl' : 'ltr';
      document.documentElement.lang = language;
    }
  }, [language, isRTL]);

  return (
    <ThemeProvider defaultTheme="light" storageKey="sns-ui-theme">
      <QueryClientProvider client={queryClient}>
        <WorkflowProvider>
          <TooltipProvider>
            <ChatbotProvider 
            isChatbotOpen={isChatbotOpen} 
            onChatbotToggle={() => setIsChatbotOpen(!isChatbotOpen)}
          >
            <div className="flex h-screen bg-gray-50 dark:bg-gray-900">
              <Sidebar 
                isOpen={isSidebarOpen} 
                onToggle={() => setIsSidebarOpen(!isSidebarOpen)}
              />
              <main className="flex-1 overflow-hidden flex flex-col">
                <div className="flex-shrink-0">
                  <Header 
                    title="Smart National Solutions" 
                    subtitle="RFP Management System"
                  />
                </div>
                <div className="flex-1 overflow-hidden">
                  <MainContent 
                    isChatbotOpen={isChatbotOpen} 
                    onChatbotToggle={() => setIsChatbotOpen(!isChatbotOpen)}
                    onChatbotClose={() => setIsChatbotOpen(false)}
                  />
                </div>
              </main>
            </div>
            <Toaster />
          </ChatbotProvider>
          </TooltipProvider>
        </WorkflowProvider>
      </QueryClientProvider>
    </ThemeProvider>
  );
}

export default App;
